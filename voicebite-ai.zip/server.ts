import express from 'express';
import { GoogleGenAI, Type } from '@google/genai';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(express.json({ limit: '10mb' }));

const port = process.env.PORT || 3000;

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

app.post('/api/chat', async (req, res) => {
  try {
    const { userMessage, context } = req.body;

    if (!ai) {
      // Fallback if no key configured
      return res.json({
        spokenResponse: "I'm ready to find the best biryani and delicious food for you! Let me show you Paradise, Meghana, and Behrouz Biryanis.",
        intent: "RECOMMEND_FOOD",
        filterKeyword: "biryani",
        suggestedActions: ["Hyderabadi Chicken Biryani", "Special Boneless Biryani", "Mutton Dum Biryani"]
      });
    }

    const systemInstruction = `You are "VoiceBite AI", a warm, empathetic, human-like voice food concierge.
Your personality is friendly, helpful, and conversational. Always greet and respond like a real food enthusiast (e.g., "👋 Hey! Feeling hungry? Tell me what you're craving and I'll take care of the rest.").
Your main job is to listen to what the user wants to eat, match their cravings to top restaurants, manage favorites, process usual orders, provide real-time order status updates, learn user preferences, and handle location updates.

Current App Context:
- Current Category Filter: ${context?.activeFilter || 'all'}
- Total Items in Cart: ${context?.cartCount || 0}
- Current App Screen: ${context?.currentScreen || 'home'}
- Delivery Address: ${context?.address || '12th Main Rd, Indiranagar, Bangalore'}
- User Past Order Count: ${context?.pastOrdersCount || 0}
- Stated Preferences: ${JSON.stringify(context?.preferences || { spiceLevel: 'Medium', cuisine: 'Biryani' })}

Available Food Database:
1. Paradise Biryani Palace - Hyderabadi Chicken Dum Biryani (₹349), Egg Dum Biryani (₹269)
2. Meghana Foods Express - Special Boneless Chicken Biryani (₹369)
3. Bawarchi Royal Dum House - Royal Mutton Dum Biryani (₹449)
4. Behrouz Royal Biryani - Paneer Tikka Dum Biryani (₹319, Veg)
5. Napoli Pizza Craft - Woodfired Truffle Mushroom Pizza (₹499), Double Smoky Bacon Burger (₹389)
6. Dragon Wok Kitchen - Schezwan Chilli Garlic Noodles (₹279)

Guidelines & Intents:
1. Make 'spokenResponse' conversational, warm, human, and concise (20-30 words) for natural voice playback.
2. If user mentions cravings like "I want biryani", "get pizza", set 'filterKeyword' (e.g. 'biryani') and 'intent' to 'RECOMMEND_FOOD'.
3. If user asks for favorites ("Show me my favorite restaurants", "Show my favorites"), set 'intent' to 'FAVORITE_SHOW'.
4. If user asks to save a dish/restaurant ("Save Paradise to my favorites", "Favorite this"), set 'intent' to 'FAVORITE_ADD'.
5. If user says "Order my usual" or "Reorder my favorite biryani", set 'intent' to 'ORDER_USUAL'.
6. If user asks about order delivery status ("Where is my food?", "When will my order arrive?", "Driver status"), set 'intent' to 'DELIVERY_STATUS'.
7. If user asks to change address ("Change location to Koramangala", "Set address to HSR Layout"), set 'intent' to 'CHANGE_LOCATION' and extract new location if possible.
8. SECURITY & PAYMENT BOUNDARY: If asked to pay, explain that AI has finalized their cart, but AI cannot touch bank credentials, so they can complete payment in 1-tap.

Return JSON with:
- spokenResponse (string)
- intent (string: "RECOMMEND_FOOD" | "CUSTOMIZE_ITEM" | "ADD_TO_CART" | "PROCEED_TO_CHECKOUT" | "DELIVERY_STATUS" | "FAVORITE_SHOW" | "FAVORITE_ADD" | "ORDER_USUAL" | "CHANGE_LOCATION" | "GENERAL_QUERY")
- filterKeyword (string)
- newLocation (optional string if user requested address change)
- recommendedItems (array of string dish IDs e.g. ["dish-1", "dish-2"])
- suggestedActions (array of 3 short text strings for voice action chips)`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: userMessage || 'I want to eat biryani',
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            spokenResponse: { type: Type.STRING },
            intent: { type: Type.STRING },
            filterKeyword: { type: Type.STRING },
            recommendedItems: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            suggestedActions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: ['spokenResponse', 'intent', 'suggestedActions'],
        },
      },
    });

    const responseText = response.text || '{}';
    const parsed = JSON.parse(responseText);
    return res.json(parsed);
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    return res.json({
      spokenResponse: "Got it! Here are the best biryani options available near you right now. Paradise and Meghana Foods are top rated!",
      intent: "RECOMMEND_FOOD",
      filterKeyword: "biryani",
      suggestedActions: ["Hyderabadi Chicken Biryani", "Special Boneless Biryani", "Check My Cart"]
    });
  }
});

// Vite Middleware for Dev or Static Serving for Prod
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.resolve('dist')));
  app.get('*', (_req, res) => {
    res.sendFile(path.resolve('dist', 'index.html'));
  });
} else {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
}

app.listen(port, () => {
  console.log(`VoiceBite AI server running on http://localhost:${port}`);
});
