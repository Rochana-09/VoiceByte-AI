import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { VoiceSensorHero } from './components/VoiceSensor/VoiceSensorHero';
import { CategoryPills } from './components/RestaurantList/CategoryPills';
import { DishCard } from './components/RestaurantList/DishCard';
import { ItemModal } from './components/Customization/ItemModal';
import { CartDrawer } from './components/Cart/CartDrawer';
import { PaymentModal } from './components/Checkout/PaymentModal';
import { DeliveryTracker } from './components/Delivery/DeliveryTracker';
import { LocationModal } from './components/Header/LocationModal';
import { FavoritesDrawer } from './components/Favorites/FavoritesDrawer';
import { RecommendationBanner } from './components/Recommendations/RecommendationBanner';
import { RESTAURANTS, MENU_ITEMS, DEFAULT_DELIVERY_PARTNER } from './data/mockData';
import { MenuItem, CartItem, VoiceMessage, Order } from './types/food';
import { voiceService } from './services/voiceService';
import { sendVoiceMessageToAI } from './services/apiService';
import { Sparkles, ShoppingBag, MapPin, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [activeFilter, setActiveFilter] = useState('all');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [customizingDish, setCustomizingDish] = useState<MenuItem | null>(null);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [deliveryAddress, setDeliveryAddress] = useState('12th Main Rd, Indiranagar, Bangalore');

  // New Modals & Features State
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [isFavoritesOpen, setIsFavoritesOpen] = useState(false);
  const [favoriteDishIds, setFavoriteDishIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('voicebite_favorite_dishes');
      return saved ? JSON.parse(saved) : ['dish-1', 'dish-2'];
    } catch {
      return ['dish-1', 'dish-2'];
    }
  });
  const [favoriteRestaurantIds, setFavoriteRestaurantIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('voicebite_favorite_restaurants');
      return saved ? JSON.parse(saved) : ['rest-1'];
    } catch {
      return ['rest-1'];
    }
  });
  const [pastOrdersCount, setPastOrdersCount] = useState(3);
  const [userPreferences, setUserPreferences] = useState({
    spiceLevel: 'Medium-Spicy',
    isVegOnly: false,
    favoriteCategory: 'Biryani',
  });

  // Voice State
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [transcript, setTranscript] = useState('');
  const [voiceVolume, setVoiceVolume] = useState(0);
  const [hasStarted, setHasStarted] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [thinkingSteps, setThinkingSteps] = useState<string[]>([]);

  const [suggestedActions, setSuggestedActions] = useState<string[]>([
    'Order my usual biryani',
    'Where is my order status?',
    'Change delivery address',
  ]);

  const [conversation, setConversation] = useState<VoiceMessage[]>([
    {
      id: 'msg-welcome',
      sender: 'ai',
      text: "👋 Hey! Feeling hungry? Tell me what you're craving and I'll take care of the rest.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  // Sync favorites to local storage
  useEffect(() => {
    localStorage.setItem('voicebite_favorite_dishes', JSON.stringify(favoriteDishIds));
  }, [favoriteDishIds]);

  useEffect(() => {
    localStorage.setItem('voicebite_favorite_restaurants', JSON.stringify(favoriteRestaurantIds));
  }, [favoriteRestaurantIds]);

  // Total cart calculation
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce((sum, item) => sum + item.totalPrice, 0);

  // Toggle Favorite Handlers
  const toggleFavoriteDish = (dishId: string) => {
    setFavoriteDishIds((prev) =>
      prev.includes(dishId) ? prev.filter((id) => id !== dishId) : [...prev, dishId]
    );
  };

  const toggleFavoriteRestaurant = (restId: string) => {
    setFavoriteRestaurantIds((prev) =>
      prev.includes(restId) ? prev.filter((id) => id !== restId) : [...prev, restId]
    );
  };

  // Order Usual Action
  const handleOrderUsual = () => {
    // Add first favorite dish or top bestseller to cart
    const usualDish = MENU_ITEMS.find((d) => favoriteDishIds.includes(d.id)) || MENU_ITEMS[0];
    handleAddToCart({
      id: `cart-${Date.now()}`,
      menuItem: usualDish,
      quantity: 1,
      totalPrice: usualDish.price,
    });
    setIsCartOpen(true);

    const spokenText = `Added your usual ${usualDish.name} to your cart! Ready to review and pay?`;
    setConversation((prev) => [
      ...prev,
      {
        id: `ai-usual-${Date.now()}`,
        sender: 'ai',
        text: spokenText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);

    if (soundEnabled) {
      voiceService.speak(spokenText);
    }
  };

  // Filter menu items based on active voice/category filter
  const filteredDishes = MENU_ITEMS.filter((dish) => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'veg') return dish.isVeg;
    if (activeFilter === 'favorites') return favoriteDishIds.includes(dish.id);
    if (activeFilter === 'recommendations') return dish.bestseller || favoriteDishIds.includes(dish.id);
    return dish.category.toLowerCase() === activeFilter.toLowerCase();
  });

  // Handle Voice Processing
  const processUserQuery = async (userText: string) => {
    if (!userText.trim()) return;

    setHasStarted(true);

    // 1. Append User Message
    const userMsg: VoiceMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setConversation((prev) => [...prev, userMsg]);
    setTranscript('');

    // 2. Start Animated Thinking Steps Visualizer
    const lower = userText.toLowerCase();
    let topic = 'nearby restaurants';
    if (lower.includes('biryani')) topic = 'biryani spots';
    else if (lower.includes('pizza')) topic = 'woodfired pizzerias';
    else if (lower.includes('burger')) topic = 'burger joints';

    setIsThinking(true);
    setThinkingSteps([`Finding ${topic}...`]);

    const timer1 = setTimeout(() => {
      setThinkingSteps((prev) => [...prev, 'Comparing ratings & reviews...']);
    }, 400);

    const timer2 = setTimeout(() => {
      setThinkingSteps((prev) => [...prev, 'Checking live delivery times...']);
    }, 800);

    // 3. Call Gemini AI via Server API
    const aiResponse = await sendVoiceMessageToAI(userText, {
      activeFilter,
      cartCount,
      currentScreen: activeOrder ? 'delivery' : 'home',
      address: deliveryAddress,
      pastOrdersCount,
      preferences: userPreferences,
    });

    // 4. Ensure minimum delay so user sees full thinking animation sequence
    setTimeout(() => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      setIsThinking(false);
      setThinkingSteps([]);

      // Append AI Message
      const aiMsg: VoiceMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: aiResponse.spokenResponse,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedActions: aiResponse.suggestedActions,
        filterKeyword: aiResponse.filterKeyword,
      };

      setConversation((prev) => [...prev, aiMsg]);

      if (aiResponse.suggestedActions) {
        setSuggestedActions(aiResponse.suggestedActions);
      }

      // Execute Intents
      if (aiResponse.intent === 'FAVORITE_SHOW') {
        setIsFavoritesOpen(true);
      } else if (aiResponse.intent === 'FAVORITE_ADD') {
        const topDish = MENU_ITEMS[0];
        if (!favoriteDishIds.includes(topDish.id)) {
          toggleFavoriteDish(topDish.id);
        }
      } else if (aiResponse.intent === 'ORDER_USUAL') {
        handleOrderUsual();
      } else if (aiResponse.intent === 'CHANGE_LOCATION') {
        if (aiResponse.newLocation) {
          setDeliveryAddress(aiResponse.newLocation);
        } else {
          setIsLocationModalOpen(true);
        }
      } else if (aiResponse.intent === 'DELIVERY_STATUS') {
        if (!activeOrder) {
          const noOrderText = "You don't have an active order right now. Would you like to place a new order for Biryani?";
          setConversation((prev) => [
            ...prev,
            {
              id: `ai-noorder-${Date.now()}`,
              sender: 'ai',
              text: noOrderText,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            },
          ]);
          if (soundEnabled) voiceService.speak(noOrderText);
        }
      } else if (aiResponse.intent === 'PROCEED_TO_CHECKOUT') {
        if (cart.length > 0) {
          setIsCartOpen(false);
          setIsPaymentOpen(true);
        } else {
          const topBiryani = MENU_ITEMS[0];
          handleAddToCart({
            id: `cart-${Date.now()}`,
            menuItem: topBiryani,
            quantity: 1,
            totalPrice: topBiryani.price,
          });
          setIsPaymentOpen(true);
        }
      }

      if (aiResponse.filterKeyword && aiResponse.intent === 'RECOMMEND_FOOD') {
        setActiveFilter(aiResponse.filterKeyword.toLowerCase());
      }

      // Speak AI response via Web Speech Synthesis if sound is enabled
      if (soundEnabled) {
        setIsSpeaking(true);
        voiceService.speak(
          aiResponse.spokenResponse,
          () => setIsSpeaking(true),
          () => setIsSpeaking(false)
        );
      }
    }, 1100);
  };

  // Start Mic Voice Recognition
  const handleStartListening = () => {
    setHasStarted(true);
    voiceService.stopSpeaking();
    setIsSpeaking(false);

    voiceService.startListening({
      onStart: () => {
        setIsListening(true);
        setTranscript('Listening to your voice...');
      },
      onVolumeChange: (vol) => {
        setVoiceVolume(vol);
      },
      onResult: (text, isFinal) => {
        setTranscript(text);
        if (isFinal && text.trim()) {
          voiceService.stopListening();
          setIsListening(false);
          setVoiceVolume(0);
          processUserQuery(text);
        }
      },
      onError: (err) => {
        console.warn('Voice sensor error:', err);
        setIsListening(false);
        setVoiceVolume(0);
        setTranscript('');
        // Add helpful guide message to conversation
        setConversation((prev) => [
          ...prev,
          {
            id: `err-${Date.now()}`,
            sender: 'ai',
            text: `${err} You can also tap any voice prompt chip below or type in the bar!`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      },
      onEnd: () => {
        setIsListening(false);
        setVoiceVolume(0);
      },
    });
  };

  const handleStopListening = () => {
    voiceService.stopListening();
    setIsListening(false);
  };

  // Cart Management
  const handleAddToCart = (item: CartItem) => {
    setCart((prev) => [...prev, item]);
  };

  const handleUpdateQuantity = (cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveCartItem(cartItemId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        if (item.id === cartItemId) {
          const unitPrice = item.totalPrice / item.quantity;
          return {
            ...item,
            quantity: newQty,
            totalPrice: unitPrice * newQty,
          };
        }
        return item;
      })
    );
  };

  const handleRemoveCartItem = (cartItemId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== cartItemId));
  };

  // Payment Completion
  const handlePaymentSuccess = (method: 'UPI' | 'Card' | 'COD' | 'ApplePay') => {
    const subtotal = cartSubtotal;
    const deliveryFee = subtotal > 500 ? 0 : 35;
    const taxes = Math.round(subtotal * 0.05);

    const newOrder: Order = {
      id: `ORD-${Math.floor(100000 + Math.random() * 900000)}`,
      items: cart,
      subtotal,
      deliveryFee,
      taxes,
      grandTotal: subtotal + deliveryFee + taxes,
      deliveryAddress,
      customerName: 'Rohit Kumar',
      customerPhone: '+91 98765 00112',
      status: 'preparing',
      deliveryPartner: DEFAULT_DELIVERY_PARTNER,
      estimatedDeliveryTime: 20,
      createdAt: new Date().toISOString(),
      paymentMethod: method,
      paymentCompleted: true,
    };

    setActiveOrder(newOrder);
    setCart([]);
    setIsPaymentOpen(false);

    // Speak confirmation message via AI
    const confirmText = `Order confirmed! Payment of ₹${newOrder.grandTotal} completed. Rahul Kumar has been assigned as your delivery partner and will arrive in 20 minutes!`;
    setConversation((prev) => [
      ...prev,
      {
        id: `ai-order-${Date.now()}`,
        sender: 'ai',
        text: confirmText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);

    if (soundEnabled) {
      voiceService.speak(confirmText);
    }
  };

  // If user has an active order, show Live Delivery Assistant Screen
  if (activeOrder) {
    return (
      <DeliveryTracker
        order={activeOrder}
        onBackToHome={() => setActiveOrder(null)}
        onSendVoiceQuery={(query) => processUserQuery(query)}
        isListening={isListening}
        isSpeaking={isSpeaking}
        onToggleMic={isListening ? handleStopListening : handleStartListening}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#050508] text-white flex flex-col font-sans selection:bg-emerald-400 selection:text-black">
      {/* Header Bar */}
      <Header
        cartCount={cartCount}
        cartTotal={cartSubtotal}
        onOpenCart={() => setIsCartOpen(true)}
        isListening={isListening}
        isSpeaking={isSpeaking}
        onToggleMic={isListening ? handleStopListening : handleStartListening}
        soundEnabled={soundEnabled}
        onToggleSound={() => {
          if (soundEnabled) {
            voiceService.stopSpeaking();
          }
          setSoundEnabled(!soundEnabled);
        }}
        currentAddress={deliveryAddress}
        onAddressClick={() => setIsLocationModalOpen(true)}
        onOpenFavorites={() => setIsFavoritesOpen(true)}
        favoritesCount={favoriteDishIds.length}
        hasActiveOrder={!!activeOrder}
        onViewOrderTracker={() => setActiveOrder(activeOrder)}
      />

      {/* Hero Voice Sensor Interaction Center */}
      <VoiceSensorHero
        isListening={isListening}
        isSpeaking={isSpeaking}
        transcript={transcript}
        onStartListening={handleStartListening}
        onStopListening={handleStopListening}
        onSendTextQuery={(text) => processUserQuery(text)}
        conversation={conversation}
        suggestedActions={suggestedActions}
        activeFilter={activeFilter}
        voiceVolume={voiceVolume}
        hasStarted={hasStarted}
        isThinking={isThinking}
        thinkingSteps={thinkingSteps}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 lg:px-8 py-8 space-y-6">
        {/* Recommendation Engine Banner */}
        <RecommendationBanner
          pastOrdersCount={pastOrdersCount}
          userPreferences={userPreferences}
          recommendedDishes={MENU_ITEMS.filter((d) => d.bestseller || favoriteDishIds.includes(d.id))}
          onSelectDish={(dish) => setCustomizingDish(dish)}
          onAnswerClarification={(answer) => processUserQuery(answer)}
        />

        {/* Category Filters */}
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium text-white tracking-tight flex items-center gap-2">
              <span>Explore Cravings</span>
              {activeFilter !== 'all' && (
                <span className="text-xs text-emerald-400 font-medium">({filteredDishes.length} items found)</span>
              )}
            </h2>

            {activeFilter !== 'all' && (
              <button
                onClick={() => setActiveFilter('all')}
                className="text-xs text-emerald-400 hover:underline font-medium cursor-pointer"
              >
                Clear Filter
              </button>
            )}
          </div>

          <CategoryPills
            selectedCategory={activeFilter}
            onSelectCategory={(cat) => setActiveFilter(cat)}
            favoritesCount={favoriteDishIds.length}
          />
        </section>

        {/* Featured Restaurants Header Banner */}
        {activeFilter === 'biryani' || activeFilter === 'all' ? (
          <section className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
            
            <div className="space-y-1.5 text-center md:text-left relative z-10">
              <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/30">
                👑 Biryani Capital
              </span>
              <h3 className="text-xl sm:text-2xl font-light tracking-wide text-white">
                Best Authentic <span className="text-emerald-400 font-semibold">Hyderabadi Dum Biryanis</span>
              </h3>
              <p className="text-xs text-white/50 max-w-xl leading-relaxed">
                Paradise Biryani, Meghana Foods & Behrouz Royal Biryanis prepared with slow dum cooking and fragrant saffron basmati rice.
              </p>
            </div>

            <button
              onClick={() => processUserQuery("Recommend the top rated biryani from Paradise")}
              className="bg-emerald-400 hover:bg-emerald-300 text-black font-semibold text-xs px-6 py-3 rounded-full shadow-[0_0_20px_rgba(52,211,153,0.3)] transition-all shrink-0 cursor-pointer flex items-center gap-2 relative z-10"
            >
              <Sparkles className="w-4 h-4" />
              <span>Ask AI Top Biryani Pick</span>
            </button>
          </section>
        ) : null}

        {/* Food Dish Grid */}
        <section className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDishes.map((dish) => (
              <DishCard
                key={dish.id}
                dish={dish}
                onSelectDish={(selected) => setCustomizingDish(selected)}
                isRecommended={dish.category === activeFilter || (activeFilter === 'all' && dish.bestseller)}
                isFavorite={favoriteDishIds.includes(dish.id)}
                onToggleFavorite={toggleFavoriteDish}
              />
            ))}
          </div>

          {filteredDishes.length === 0 && (
            <div className="text-center py-16 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 space-y-3">
              <p className="text-white/50 font-medium text-sm">No items found matching "{activeFilter}"</p>
              <button
                onClick={() => setActiveFilter('all')}
                className="bg-emerald-400 text-black font-semibold px-5 py-2.5 rounded-full text-xs cursor-pointer"
              >
                Show All Dishes
              </button>
            </div>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-[#050508] border-t border-white/10 py-6 text-center text-xs text-white/40">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© 2026 VoiceBite AI • Immersive Voice Sensor Food Assistant</p>
          <p className="text-[11px] text-white/30">Powered by Gemini 3.6 & Server-side AI Proxy</p>
        </div>
      </footer>

      {/* Item Customization Modal */}
      <ItemModal
        dish={customizingDish}
        onClose={() => setCustomizingDish(null)}
        onAddToCart={handleAddToCart}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveCartItem}
        onProceedToPayment={() => {
          setIsCartOpen(false);
          setIsPaymentOpen(true);
        }}
        deliveryAddress={deliveryAddress}
      />

      {/* Human Payment Security Portal Modal */}
      <PaymentModal
        isOpen={isPaymentOpen}
        onClose={() => setIsPaymentOpen(false)}
        cartItems={cart}
        grandTotal={cartSubtotal + (cartSubtotal > 500 ? 0 : 35) + Math.round(cartSubtotal * 0.05)}
        deliveryAddress={deliveryAddress}
        onPaymentSuccess={handlePaymentSuccess}
      />

      {/* Delivery Address Location Modal */}
      <LocationModal
        isOpen={isLocationModalOpen}
        onClose={() => setIsLocationModalOpen(false)}
        currentAddress={deliveryAddress}
        onSelectAddress={(newAddress) => setDeliveryAddress(newAddress)}
      />

      {/* Saved Favorites Drawer */}
      <FavoritesDrawer
        isOpen={isFavoritesOpen}
        onClose={() => setIsFavoritesOpen(false)}
        favoriteDishIds={favoriteDishIds}
        favoriteRestaurantIds={favoriteRestaurantIds}
        allDishes={MENU_ITEMS}
        allRestaurants={RESTAURANTS}
        onToggleFavoriteDish={toggleFavoriteDish}
        onToggleFavoriteRestaurant={toggleFavoriteRestaurant}
        onSelectDish={(dish) => setCustomizingDish(dish)}
        onOrderUsual={handleOrderUsual}
      />
    </div>
  );
}
