import React from 'react';
import { X, Trash2, ShoppingBag, MapPin, ArrowRight, ShieldCheck, Plus, Minus, Tag } from 'lucide-react';
import { CartItem } from '../../types/food';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (cartItemId: string, newQty: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onProceedToPayment: () => void;
  deliveryAddress: string;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToPayment,
  deliveryAddress,
}) => {
  if (!isOpen) return null;

  const subtotal = cartItems.reduce((sum, item) => sum + item.totalPrice, 0);
  const deliveryFee = subtotal > 0 ? (subtotal > 500 ? 0 : 35) : 0;
  const taxes = Math.round(subtotal * 0.05); // 5% GST
  const grandTotal = subtotal + deliveryFee + taxes;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fadeIn">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/80 backdrop-blur-md transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#050508] border-l border-white/10 text-white shadow-2xl flex flex-col justify-between">
          {/* Header */}
          <div className="p-5 bg-black/60 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-medium text-white">Your Order Cart</h2>
                <p className="text-xs text-white/50">{cartItems.length} {cartItems.length === 1 ? 'item' : 'items'} selected</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full text-white/50 hover:text-white hover:bg-white/10 transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {cartItems.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-white/40 space-y-3">
                <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/30 mb-2">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="font-medium text-white text-base">Your cart is empty</h3>
                <p className="text-xs text-white/40 max-w-xs leading-relaxed">
                  Speak to AI or select delicious biryani & food items to add them to your cart!
                </p>
              </div>
            ) : (
              cartItems.map((item) => (
                <div
                  key={item.id}
                  className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-4 space-y-2 shadow-sm"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className={`w-2 h-2 rounded-full ${item.menuItem.isVeg ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                        <h4 className="font-medium text-sm text-white">{item.menuItem.name}</h4>
                      </div>
                      <p className="text-[11px] text-white/40 mt-0.5">{item.menuItem.restaurantName}</p>

                      {/* Selected Customization Summary */}
                      <div className="mt-1.5 flex flex-wrap gap-1 text-[10px] text-emerald-300">
                        {item.selectedSize && (
                          <span className="bg-white/5 px-2 py-0.5 rounded-full border border-white/10">
                            {item.selectedSize.name}
                          </span>
                        )}
                        {item.selectedSpice && (
                          <span className="bg-white/5 px-2 py-0.5 rounded-full border border-white/10">
                            🔥 {item.selectedSpice}
                          </span>
                        )}
                        {item.selectedAddOns?.map((a, idx) => (
                          <span key={idx} className="bg-white/5 px-2 py-0.5 rounded-full border border-white/10">
                            +{a.name}
                          </span>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="text-white/40 hover:text-rose-400 p-1 transition-colors cursor-pointer"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-white/10">
                    <div className="flex items-center gap-2 bg-black/40 border border-white/10 rounded-full p-1">
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                        className="p-1 text-white/70 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-semibold text-white px-2">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                        className="p-1 text-white/70 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                    <span className="font-mono text-sm text-emerald-400 font-bold">₹{item.totalPrice}</span>
                  </div>
                </div>
              ))
            )}

            {/* Delivery Address Box */}
            {cartItems.length > 0 && (
              <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-1.5">
                <div className="flex items-center justify-between text-xs text-white/50">
                  <span className="flex items-center gap-1.5 font-medium text-white/80">
                    <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                    Delivery Destination
                  </span>
                  <span className="text-[10px] text-emerald-400 font-semibold">Change</span>
                </div>
                <p className="text-xs text-white/70 font-medium pl-5">{deliveryAddress}</p>
              </div>
            )}
          </div>

          {/* Footer & Price Breakdown */}
          {cartItems.length > 0 && (
            <div className="p-5 bg-black/60 border-t border-white/10 space-y-3.5 shrink-0">
              <div className="space-y-1.5 text-xs text-white/70">
                <div className="flex justify-between">
                  <span>Item Subtotal</span>
                  <span className="font-mono text-white">₹{subtotal}</span>
                </div>
                <div className="flex justify-between">
                  <span>Delivery Partner Fee</span>
                  <span className="font-mono text-white">
                    {deliveryFee === 0 ? <span className="text-emerald-400 font-sans font-semibold">FREE</span> : `₹${deliveryFee}`}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Taxes & Restaurant Packing</span>
                  <span className="font-mono text-white">₹{taxes}</span>
                </div>
                <div className="pt-2 border-t border-white/10 flex justify-between text-sm font-semibold text-white">
                  <span>To Pay</span>
                  <span className="text-emerald-400 font-mono text-base font-bold">₹{grandTotal}</span>
                </div>
              </div>

              {/* AI Payment Security Boundary Notice */}
              <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-3 flex items-start gap-2 text.xs text-emerald-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <p className="text-[11px] leading-snug">
                  <strong className="text-emerald-200">AI Safety Boundary:</strong> Payment is handled strictly in your secure human payment modal.
                </p>
              </div>

              {/* Proceed to Payment Button */}
              <button
                onClick={onProceedToPayment}
                className="w-full flex items-center justify-center gap-2 bg-emerald-400 hover:bg-emerald-300 text-black font-semibold text-sm py-3.5 px-6 rounded-full shadow-[0_0_20px_rgba(52,211,153,0.3)] transition-all cursor-pointer"
              >
                <span>Proceed to Human Payment (₹{grandTotal})</span>
                <ArrowRight className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
