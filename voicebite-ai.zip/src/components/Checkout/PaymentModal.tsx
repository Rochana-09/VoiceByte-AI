import React, { useState } from 'react';
import { Shield, Lock, CreditCard, Smartphone, CheckCircle, ArrowRight, DollarSign, Sparkles, X } from 'lucide-react';
import { CartItem } from '../../types/food';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  grandTotal: number;
  deliveryAddress: string;
  onPaymentSuccess: (paymentMethod: 'UPI' | 'Card' | 'COD' | 'ApplePay') => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  grandTotal,
  deliveryAddress,
  onPaymentSuccess,
}) => {
  if (!isOpen) return null;

  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'Card' | 'COD' | 'ApplePay'>('UPI');
  const [upiId, setUpiId] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePayNow = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simulate instant secure payment processing
    setTimeout(() => {
      setIsProcessing(false);
      onPaymentSuccess(paymentMethod);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#050508] border border-white/10 text-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-5 bg-black/60 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-medium text-white">Human Payment Portal</h2>
              <p className="text-xs text-emerald-400 font-medium">AI Isolated • 256-bit Encrypted</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-white/50 hover:text-white hover:bg-white/10 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Security Warning Notice */}
        <div className="p-4 bg-emerald-500/10 border-b border-emerald-500/20 px-5 flex items-start gap-3">
          <Shield className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="text-xs text-emerald-200 space-y-0.5">
            <span className="font-semibold text-emerald-300 block">AI Firewall Active:</span>
            <p className="leading-relaxed text-emerald-200/80">
              AI assisted with order assembly, but <strong className="text-white">AI cannot read or store bank credentials</strong>. Payment is handled directly by you.
            </p>
          </div>
        </div>

        {/* Order Summary Brief */}
        <div className="p-5 overflow-y-auto space-y-5">
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-4 space-y-2">
            <div className="flex justify-between items-center text-xs font-medium text-white/80">
              <span>Order Summary ({cartItems.length} items)</span>
              <span className="text-emerald-400 font-mono text-base font-bold">Total: ₹{grandTotal}</span>
            </div>
            <div className="text-[11px] text-white/50 space-y-0.5">
              {cartItems.map((item, idx) => (
                <div key={idx} className="flex justify-between">
                  <span>{item.quantity}x {item.menuItem.name}</span>
                  <span className="font-mono">₹{item.totalPrice}</span>
                </div>
              ))}
            </div>
            <div className="pt-2 border-t border-white/10 text-[11px] text-white/60 font-medium">
              📍 Delivering to: <span className="text-white font-medium">{deliveryAddress}</span>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div>
            <label className="block text-xs font-medium text-white/60 uppercase tracking-widest mb-2.5">
              Select Payment Method
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setPaymentMethod('UPI')}
                className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-2 text-xs font-medium transition-all cursor-pointer ${
                  paymentMethod === 'UPI'
                    ? 'bg-emerald-500/10 border-emerald-400 text-white shadow-md'
                    : 'bg-black/40 border-white/10 text-white/50 hover:text-white'
                }`}
              >
                <Smartphone className={`w-5 h-5 ${paymentMethod === 'UPI' ? 'text-emerald-400' : ''}`} />
                <span>UPI (GPay / PhonePe)</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('Card')}
                className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-2 text-xs font-medium transition-all cursor-pointer ${
                  paymentMethod === 'Card'
                    ? 'bg-emerald-500/10 border-emerald-400 text-white shadow-md'
                    : 'bg-black/40 border-white/10 text-white/50 hover:text-white'
                }`}
              >
                <CreditCard className={`w-5 h-5 ${paymentMethod === 'Card' ? 'text-emerald-400' : ''}`} />
                <span>Credit / Debit Card</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('ApplePay')}
                className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-2 text-xs font-medium transition-all cursor-pointer ${
                  paymentMethod === 'ApplePay'
                    ? 'bg-emerald-500/10 border-emerald-400 text-white shadow-md'
                    : 'bg-black/40 border-white/10 text-white/50 hover:text-white'
                }`}
              >
                <Sparkles className={`w-5 h-5 ${paymentMethod === 'ApplePay' ? 'text-emerald-400' : ''}`} />
                <span>Apple Pay / GPay</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('COD')}
                className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-2 text-xs font-medium transition-all cursor-pointer ${
                  paymentMethod === 'COD'
                    ? 'bg-emerald-500/10 border-emerald-400 text-white shadow-md'
                    : 'bg-black/40 border-white/10 text-white/50 hover:text-white'
                }`}
              >
                <DollarSign className={`w-5 h-5 ${paymentMethod === 'COD' ? 'text-emerald-400' : ''}`} />
                <span>Cash on Delivery</span>
              </button>
            </div>
          </div>

          {/* Payment Method Inputs */}
          <form onSubmit={handlePayNow} className="space-y-4">
            {paymentMethod === 'UPI' && (
              <div>
                <label className="block text-xs font-medium text-white/60 mb-1.5">Enter VPA / UPI ID</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. user@okaxis or 9876543210@paytm"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 focus:border-emerald-400 rounded-full px-4 py-2.5 text-xs text-white placeholder-white/30 outline-none"
                />
              </div>
            )}

            {paymentMethod === 'Card' && (
              <div className="space-y-2.5">
                <div>
                  <label className="block text-xs font-medium text-white/60 mb-1">Card Number</label>
                  <input
                    type="text"
                    required
                    placeholder="4532 •••• •••• 8812"
                    className="w-full bg-white/5 border border-white/10 focus:border-emerald-400 rounded-full px-4 py-2.5 text-xs text-white placeholder-white/30 outline-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-medium text-white/60 mb-1">Expiry</label>
                    <input
                      type="text"
                      required
                      placeholder="MM/YY"
                      className="w-full bg-white/5 border border-white/10 focus:border-emerald-400 rounded-full px-4 py-2.5 text-xs text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-white/60 mb-1">CVV</label>
                    <input
                      type="password"
                      maxLength={4}
                      required
                      placeholder="•••"
                      className="w-full bg-white/5 border border-white/10 focus:border-emerald-400 rounded-full px-4 py-2.5 text-xs text-white outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Pay Action Button */}
            <button
              type="submit"
              disabled={isProcessing}
              className="w-full mt-2 flex items-center justify-center gap-2 bg-emerald-400 hover:bg-emerald-300 text-black font-semibold text-sm py-3.5 px-6 rounded-full shadow-[0_0_20px_rgba(52,211,153,0.3)] transition-all cursor-pointer disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  <span>Authorizing Human Payment...</span>
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 stroke-[2.5]" />
                  <span>Pay ₹{grandTotal} & Launch Live AI Delivery Assistant</span>
                  <ArrowRight className="w-4 h-4 stroke-[2.5]" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
