import React, { useState } from 'react';
import { X, Check, Flame, Plus, Minus, ShoppingBag, Mic } from 'lucide-react';
import { MenuItem, CartItem } from '../../types/food';

interface ItemModalProps {
  dish: MenuItem | null;
  onClose: () => void;
  onAddToCart: (cartItem: CartItem) => void;
}

export const ItemModal: React.FC<ItemModalProps> = ({
  dish,
  onClose,
  onAddToCart,
}) => {
  if (!dish) return null;

  const [selectedSize, setSelectedSize] = useState(
    dish.customizations?.sizes?.[0] || { name: 'Standard Portion', price: 0 }
  );
  const [selectedSpice, setSelectedSpice] = useState(
    dish.customizations?.spiceLevels?.[1] || 'Medium Spicy'
  );
  const [selectedAddOns, setSelectedAddOns] = useState<{ name: string; price: number }[]>([]);
  const [quantity, setQuantity] = useState(1);
  const [instructions, setInstructions] = useState('');

  const toggleAddOn = (addon: { name: string; price: number }) => {
    if (selectedAddOns.some(a => a.name === addon.name)) {
      setSelectedAddOns(selectedAddOns.filter(a => a.name !== addon.name));
    } else {
      setSelectedAddOns([...selectedAddOns, addon]);
    }
  };

  const addOnsTotal = selectedAddOns.reduce((sum, a) => sum + a.price, 0);
  const unitPrice = dish.price + selectedSize.price + addOnsTotal;
  const totalPrice = unitPrice * quantity;

  const handleConfirm = () => {
    const cartItem: CartItem = {
      id: `cart-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      menuItem: dish,
      selectedSize,
      selectedSpice,
      selectedAddOns,
      quantity,
      totalPrice,
      instructions: instructions.trim() || undefined,
    };
    onAddToCart(cartItem);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#050508] border border-white/10 text-white rounded-3xl max-w-lg w-full max-h-[90vh] overflow-hidden shadow-2xl flex flex-col">
        {/* Modal Header */}
        <div className="relative h-44 w-full bg-black/40 shrink-0">
          <img
            src={dish.image}
            alt={dish.name}
            className="w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#050508] via-[#050508]/40 to-transparent" />
          <button
            onClick={onClose}
            className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 text-white/70 hover:text-white flex items-center justify-center transition-all border border-white/10 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="absolute bottom-3 left-5 right-5">
            <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">
              {dish.restaurantName}
            </span>
            <h2 className="text-xl font-medium text-white leading-tight">{dish.name}</h2>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1">
          <p className="text-xs text-white/50 leading-relaxed">{dish.description}</p>

          {/* Portion Size Selection */}
          {dish.customizations?.sizes && dish.customizations.sizes.length > 0 && (
            <div>
              <h3 className="text-xs font-medium text-white/60 uppercase tracking-widest mb-2.5">
                1. Choose Portion Size
              </h3>
              <div className="space-y-2">
                {dish.customizations.sizes.map((size, idx) => {
                  const isSelected = selectedSize.name === size.name;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedSize(size)}
                      className={`w-full flex items-center justify-between p-3 rounded-full border text-xs font-medium transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-500/10 border-emerald-400 text-white'
                          : 'bg-white/5 border-white/10 text-white/70 hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${isSelected ? 'border-emerald-400 bg-emerald-400' : 'border-white/30'}`}>
                          {isSelected && <Check className="w-2.5 h-2.5 text-black stroke-[3]" />}
                        </div>
                        <span>{size.name}</span>
                      </div>
                      <span className="font-mono text-emerald-400 font-bold">
                        {size.price > 0 ? `+₹${size.price}` : 'Included'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Spice Level Selection */}
          {dish.customizations?.spiceLevels && dish.customizations.spiceLevels.length > 0 && (
            <div>
              <h3 className="text-xs font-medium text-white/60 uppercase tracking-widest mb-2.5 flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-emerald-400" />
                <span>2. Select Spice Preference</span>
              </h3>
              <div className="grid grid-cols-3 gap-2">
                {dish.customizations.spiceLevels.map((spice, idx) => {
                  const isSelected = selectedSpice === spice;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedSpice(spice)}
                      className={`p-2.5 rounded-full border text-xs font-medium transition-all text-center cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-400 text-black border-emerald-300 font-semibold shadow-[0_0_15px_rgba(52,211,153,0.3)]'
                          : 'bg-white/5 border-white/10 text-white/70 hover:bg-white/10'
                      }`}
                    >
                      {spice}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Add-Ons */}
          {dish.customizations?.addOns && dish.customizations.addOns.length > 0 && (
            <div>
              <h3 className="text-xs font-medium text-white/60 uppercase tracking-widest mb-2.5">
                3. Delicious Sides & Add-ons
              </h3>
              <div className="space-y-2">
                {dish.customizations.addOns.map((addon, idx) => {
                  const isChecked = selectedAddOns.some(a => a.name === addon.name);
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => toggleAddOn(addon)}
                      className={`w-full flex items-center justify-between p-3 rounded-full border text-xs font-medium transition-all cursor-pointer ${
                        isChecked
                          ? 'bg-emerald-500/10 border-emerald-400 text-white'
                          : 'bg-white/5 border-white/10 text-white/70 hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-4 h-4 rounded border flex items-center justify-center ${isChecked ? 'bg-emerald-400 border-emerald-400' : 'border-white/30'}`}>
                          {isChecked && <Check className="w-2.5 h-2.5 text-black stroke-[3]" />}
                        </div>
                        <span>{addon.name}</span>
                      </div>
                      <span className="font-mono text-emerald-400 font-bold">+₹{addon.price}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Special Instructions */}
          <div>
            <label className="block text-xs font-medium text-white/60 uppercase tracking-widest mb-1.5">
              Special Voice Instructions
            </label>
            <input
              type="text"
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              placeholder="e.g. Extra raita, make it extra piping hot"
              className="w-full bg-white/5 border border-white/10 focus:border-emerald-400/80 rounded-full px-4 py-2.5 text-xs text-white placeholder-white/30 outline-none"
            />
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-5 bg-black/60 border-t border-white/10 flex items-center justify-between gap-3 shrink-0">
          {/* Quantity Selector */}
          <div className="flex items-center gap-2 bg-black/40 border border-white/10 rounded-full p-1">
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              className="p-1.5 text-white/70 hover:text-white hover:bg-white/10 rounded-full transition-all cursor-pointer"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <span className="text-sm font-semibold text-white px-2">{quantity}</span>
            <button
              onClick={() => setQuantity(quantity + 1)}
              className="p-1.5 text-white/70 hover:text-white hover:bg-white/10 rounded-full transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Add to Cart Button */}
          <button
            onClick={handleConfirm}
            className="flex-1 flex items-center justify-center gap-2 bg-emerald-400 hover:bg-emerald-300 text-black font-semibold text-sm py-3 px-6 rounded-full shadow-[0_0_20px_rgba(52,211,153,0.3)] transition-all cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4 stroke-[2.5]" />
            <span>Add Item • ₹{totalPrice}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
