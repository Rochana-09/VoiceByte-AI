import React, { useState, useEffect } from 'react';
import { Clock, Phone, MapPin, Navigation, Bike, CheckCircle2, Mic, Volume2, Sparkles, MessageSquare, ShieldCheck, ArrowLeft } from 'lucide-react';
import { Order, DeliveryPartner } from '../../types/food';

interface DeliveryTrackerProps {
  order: Order;
  onBackToHome: () => void;
  onSendVoiceQuery: (query: string) => void;
  isListening: boolean;
  isSpeaking: boolean;
  onToggleMic: () => void;
}

export const DeliveryTracker: React.FC<DeliveryTrackerProps> = ({
  order,
  onBackToHome,
  onSendVoiceQuery,
  isListening,
  isSpeaking,
  onToggleMic,
}) => {
  const [etaMinutes, setEtaMinutes] = useState(order.estimatedDeliveryTime || 22);
  const [currentStepIndex, setCurrentStepIndex] = useState(2); // 'preparing'
  const [deliveryNote, setDeliveryNote] = useState('');

  // Live countdown timer for realistic tracking
  useEffect(() => {
    const timer = setInterval(() => {
      setEtaMinutes((prev) => (prev > 1 ? prev - 1 : 1));
    }, 15000); // speed up slightly for demo

    return () => clearInterval(timer);
  }, []);

  const STEPS = [
    { label: 'Order Confirmed', time: '10:58 AM', desc: 'Sent to Paradise Biryani kitchen' },
    { label: 'Kitchen Preparing Biryani', time: '11:00 AM', desc: 'Slow dum cooking & quality check' },
    { label: 'Picked Up by Rahul', time: '11:08 AM', desc: 'Sealed in insulated hot bag' },
    { label: 'On the Way to You', time: 'In progress', desc: 'Traversing 12th Main Rd' },
    { label: 'Delivered', time: 'ETA 11:20 AM', desc: 'Enjoy your hot meal!' },
  ];

  const handleVoicePrompt = (prompt: string) => {
    onSendVoiceQuery(prompt);
  };

  return (
    <div className="min-h-screen bg-[#050508] text-white p-4 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Top Navigation */}
        <div className="flex items-center justify-between">
          <button
            onClick={onBackToHome}
            className="flex items-center gap-2 text-xs font-medium text-white/80 hover:text-white bg-white/5 border border-white/10 px-4 py-2 rounded-full transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Order Food Again</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-xs font-semibold text-emerald-400 uppercase tracking-widest">Live AI Delivery Tracking</span>
          </div>
        </div>

        {/* ETA & Driver Quick Status Header */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-semibold mb-2">
                <Clock className="w-3.5 h-3.5" />
                <span>Estimated Arrival</span>
              </div>
              <h1 className="text-3xl sm:text-5xl font-light text-white tracking-tight">
                {etaMinutes} <span className="text-lg sm:text-2xl font-normal text-white/40">MINUTES</span>
              </h1>
              <p className="text-xs sm:text-sm text-white/70 mt-1">
                Rahul is bringing your delicious food from <span className="text-emerald-400 font-medium">{order.items[0]?.menuItem.restaurantName || 'Paradise Biryani'}</span>
              </p>
            </div>

            {/* AI Assistant Voice Trigger Button */}
            <div className="flex items-center gap-3">
              <button
                onClick={onToggleMic}
                className={`flex items-center gap-2 px-6 py-3 rounded-full text-xs font-semibold shadow-[0_0_20px_rgba(52,211,153,0.3)] transition-all cursor-pointer ${
                  isListening
                    ? 'bg-emerald-400 text-black animate-pulse ring-4 ring-emerald-300'
                    : 'bg-emerald-400 hover:bg-emerald-300 text-black'
                }`}
              >
                <Mic className="w-4 h-4 stroke-[2.5]" />
                <span>{isListening ? 'Listening...' : 'Ask AI Delivery Assistant'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Live Route Map Graphic Representation */}
        <div className="relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl overflow-hidden h-64 sm:h-80 shadow-2xl flex flex-col justify-between p-4">
          {/* Simulated Map Background Grid */}
          <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:20px_20px] opacity-20" />

          {/* Map Route SVG Line */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none stroke-emerald-400/60" strokeWidth="3" strokeDasharray="6 6">
            <path d="M 60 180 Q 200 80, 400 120 T 700 80" fill="none" />
          </svg>

          {/* Restaurant Pin */}
          <div className="absolute top-28 left-10 flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-emerald-400 text-black font-bold flex items-center justify-center shadow-[0_0_15px_rgba(52,211,153,0.4)]">
              🍳
            </div>
            <span className="text-[10px] font-medium text-white/80 bg-black/80 px-2.5 py-0.5 rounded-full mt-1 border border-white/10">
              {order.items[0]?.menuItem.restaurantName || 'Kitchen'}
            </span>
          </div>

          {/* Live Delivery Partner Pin (Animated Position) */}
          <div className="absolute top-20 left-1/2 -translate-x-1/2 flex flex-col items-center animate-bounce">
            <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-emerald-400 to-blue-500 text-black font-bold flex items-center justify-center shadow-xl shadow-emerald-500/30 border-2 border-white">
              <Bike className="w-6 h-6" />
            </div>
            <span className="text-[10px] font-bold text-emerald-300 bg-black/90 px-3 py-0.5 rounded-full mt-1 border border-emerald-500/40">
              Rahul • 1.2 km away
            </span>
          </div>

          {/* Delivery Home Destination Pin */}
          <div className="absolute top-12 right-12 flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-white text-black font-bold flex items-center justify-center shadow-lg">
              🏠
            </div>
            <span className="text-[10px] font-medium text-white/80 bg-black/80 px-2 py-0.5 rounded-full mt-1 border border-white/10">
              Home
            </span>
          </div>

          <div className="relative z-10 flex items-center justify-between text-xs text-white/60 bg-black/60 backdrop-blur-md p-3 rounded-2xl border border-white/10">
            <span className="flex items-center gap-1.5 font-medium text-white">
              <Navigation className="w-3.5 h-3.5 text-emerald-400" />
              Live Route: Indiranagar 100ft Rd ➔ 12th Main Destination
            </span>
            <span className="text-emerald-400 font-bold">GPS Active</span>
          </div>
        </div>

        {/* Delivery Partner Card */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-5 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src={order.deliveryPartner.photo}
              alt={order.deliveryPartner.name}
              className="w-16 h-16 rounded-full object-cover border-2 border-emerald-400/60 shadow-md"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-medium text-lg text-white">{order.deliveryPartner.name}</h3>
                <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                  ★ {order.deliveryPartner.rating}
                </span>
              </div>
              <p className="text-xs text-white/50 mt-0.5">
                {order.deliveryPartner.vehicle} • <span className="text-white/80 font-mono">{order.deliveryPartner.vehicleNumber}</span>
              </p>
              <p className="text-[11px] text-white/40 mt-0.5">{order.deliveryPartner.trips}+ deliveries completed</p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <a
              href={`tel:${order.deliveryPartner.phone}`}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-emerald-400 hover:bg-emerald-300 text-black font-semibold text-xs py-3 px-5 rounded-full transition-all shadow-md cursor-pointer"
            >
              <Phone className="w-4 h-4 stroke-[2.5]" />
              <span>Call Rahul</span>
            </a>
            <button
              onClick={() => handleVoicePrompt("Tell driver to ring bell when arriving")}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 text-white font-medium text-xs py-3 px-5 rounded-full border border-white/10 transition-all cursor-pointer"
            >
              <MessageSquare className="w-4 h-4 text-emerald-400" />
              <span>Voice Note</span>
            </button>
          </div>
        </div>

        {/* Voice Delivery Assistant Quick Queries */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-5 shadow-2xl space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
            <Sparkles className="w-4 h-4" />
            <span>Ask AI Delivery Assistant by Voice:</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button
              onClick={() => handleVoicePrompt("Where is my delivery driver right now?")}
              className="text-left bg-black/40 hover:bg-white/10 text-white/80 border border-white/10 p-3 rounded-2xl text-xs font-medium transition-all hover:border-emerald-400/40 cursor-pointer flex items-center gap-2"
            >
              <Mic className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>"Where is my driver right now?"</span>
            </button>

            <button
              onClick={() => handleVoicePrompt("How many minutes until my biryani arrives?")}
              className="text-left bg-black/40 hover:bg-white/10 text-white/80 border border-white/10 p-3 rounded-2xl text-xs font-medium transition-all hover:border-emerald-400/40 cursor-pointer flex items-center gap-2"
            >
              <Mic className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>"How many minutes until arrival?"</span>
            </button>

            <button
              onClick={() => handleVoicePrompt("Instruct driver to leave bag at door")}
              className="text-left bg-black/40 hover:bg-white/10 text-white/80 border border-white/10 p-3 rounded-2xl text-xs font-medium transition-all hover:border-emerald-400/40 cursor-pointer flex items-center gap-2"
            >
              <Mic className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>"Tell driver to leave at door"</span>
            </button>
          </div>
        </div>

        {/* Live Order Timeline Stepper */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-2xl space-y-4">
          <h3 className="font-semibold text-xs text-white/60 uppercase tracking-widest">
            Live Order Status Timeline
          </h3>

          <div className="space-y-4 relative before:absolute before:inset-0 before:left-3 before:w-0.5 before:bg-white/10">
            {STEPS.map((step, idx) => {
              const isDone = idx <= currentStepIndex;
              const isCurrent = idx === currentStepIndex;

              return (
                <div key={idx} className="relative flex items-start gap-4 pl-8">
                  <div
                    className={`absolute left-0 top-0.5 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      isDone
                        ? 'bg-emerald-400 text-black shadow-[0_0_10px_rgba(52,211,153,0.5)]'
                        : 'bg-white/10 text-white/30'
                    }`}
                  >
                    {isDone ? <CheckCircle2 className="w-4 h-4 stroke-[3]" /> : idx + 1}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className={`text-sm font-medium ${isCurrent ? 'text-emerald-400' : isDone ? 'text-white' : 'text-white/40'}`}>
                        {step.label}
                      </h4>
                      <span className="text-xs text-white/40">{step.time}</span>
                    </div>
                    <p className="text-xs text-white/50 mt-0.5">{step.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
