import React from 'react';
import { X, Heart, Plus, Star, Clock, ShoppingBag, ArrowRight } from 'lucide-react';
import { MenuItem, Restaurant } from '../../types/food';

interface FavoritesDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  favoriteDishIds: string[];
  favoriteRestaurantIds: string[];
  allDishes: MenuItem[];
  allRestaurants: Restaurant[];
  onToggleFavoriteDish: (dishId: string) => void;
  onToggleFavoriteRestaurant: (restId: string) => void;
  onSelectDish: (dish: MenuItem) => void;
  onOrderUsual: () => void;
}

export const FavoritesDrawer: React.FC<FavoritesDrawerProps> = ({
  isOpen,
  onClose,
  favoriteDishIds,
  favoriteRestaurantIds,
  allDishes,
  allRestaurants,
  onToggleFavoriteDish,
  onToggleFavoriteRestaurant,
  onSelectDish,
  onOrderUsual,
}) => {
  if (!isOpen) return null;

  const favoriteDishes = allDishes.filter((d) => favoriteDishIds.includes(d.id));
  const favoriteRestaurants = allRestaurants.filter((r) => favoriteRestaurantIds.includes(r.id));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fadeIn">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/80 backdrop-blur-md transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#050508] border-l border-white/10 text-white shadow-2xl flex flex-col justify-between">
          {/* Header */}
          <div className="p-5 bg-black/60 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
                <Heart className="w-5 h-5 fill-rose-400" />
              </div>
              <div>
                <h2 className="text-base font-medium text-white">Your Saved Favorites</h2>
                <p className="text-xs text-white/50">
                  {favoriteDishes.length} dishes • {favoriteRestaurants.length} restaurants
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full text-white/50 hover:text-white hover:bg-white/10 transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Favorites Content */}
          <div className="flex-1 overflow-y-auto p-5 space-y-6">
            {/* Quick "Order My Usual" Button if favorites exist */}
            {favoriteDishes.length > 0 && (
              <div className="bg-gradient-to-r from-emerald-500/10 via-emerald-500/5 to-transparent border border-emerald-500/30 rounded-2xl p-4 flex items-center justify-between gap-3">
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 block mb-0.5">
                    ⚡ Voice Shortcut
                  </span>
                  <h3 className="text-xs font-semibold text-white">Order My Usual</h3>
                  <p className="text-[11px] text-white/50">Auto-add favorite items to cart</p>
                </div>
                <button
                  onClick={() => {
                    onOrderUsual();
                    onClose();
                  }}
                  className="bg-emerald-400 hover:bg-emerald-300 text-black font-semibold text-xs px-4 py-2 rounded-full transition-all flex items-center gap-1.5 cursor-pointer shadow-[0_0_15px_rgba(52,211,153,0.3)] shrink-0"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>Order Usual</span>
                </button>
              </div>
            )}

            {/* Favorite Dishes Section */}
            <div>
              <h3 className="text-xs font-medium uppercase tracking-widest text-white/60 mb-3 flex items-center justify-between">
                <span>Favorite Dishes ({favoriteDishes.length})</span>
              </h3>

              {favoriteDishes.length === 0 ? (
                <div className="text-center py-8 bg-white/5 border border-white/10 rounded-2xl p-4 space-y-2 text-white/40">
                  <Heart className="w-6 h-6 mx-auto text-white/20" />
                  <p className="text-xs">No favorite dishes saved yet.</p>
                  <p className="text-[10px]">Click the heart icon on any dish or say "Save to my favorites"!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {favoriteDishes.map((dish) => (
                    <div
                      key={dish.id}
                      className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-3.5 flex items-center gap-3 relative group"
                    >
                      <img
                        src={dish.image}
                        alt={dish.name}
                        className="w-16 h-16 rounded-xl object-cover shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm text-white truncate">{dish.name}</h4>
                        <p className="text-[11px] text-white/50 truncate">{dish.restaurantName}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="font-mono text-emerald-400 font-bold text-xs">₹{dish.price}</span>
                          <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded-full text-white/70">
                            ★ {dish.rating}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => onToggleFavoriteDish(dish.id)}
                          className="p-1.5 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                          title="Remove from favorites"
                        >
                          <Heart className="w-4 h-4 fill-rose-400" />
                        </button>
                        <button
                          onClick={() => {
                            onSelectDish(dish);
                            onClose();
                          }}
                          className="w-8 h-8 rounded-full bg-emerald-400 hover:bg-emerald-300 text-black flex items-center justify-center transition-all cursor-pointer shadow-md"
                          title="Add to cart"
                        >
                          <Plus className="w-4 h-4 stroke-[3]" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Favorite Restaurants Section */}
            <div>
              <h3 className="text-xs font-medium uppercase tracking-widest text-white/60 mb-3">
                Favorite Restaurants ({favoriteRestaurants.length})
              </h3>

              {favoriteRestaurants.length === 0 ? (
                <div className="text-center py-8 bg-white/5 border border-white/10 rounded-2xl p-4 space-y-2 text-white/40">
                  <p className="text-xs">No favorite restaurants saved yet.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {favoriteRestaurants.map((rest) => (
                    <div
                      key={rest.id}
                      className="bg-white/5 border border-white/10 rounded-2xl p-3.5 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={rest.image}
                          alt={rest.name}
                          className="w-14 h-14 rounded-xl object-cover shrink-0"
                        />
                        <div className="min-w-0">
                          <h4 className="font-medium text-sm text-white truncate">{rest.name}</h4>
                          <p className="text-[11px] text-white/50 truncate">{rest.cuisine.join(', ')}</p>
                          <div className="flex items-center gap-2 mt-1 text-[10px] text-white/60">
                            <span className="text-emerald-400 font-bold">★ {rest.rating}</span>
                            <span>• {rest.deliveryTime}</span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => onToggleFavoriteRestaurant(rest.id)}
                        className="p-2 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer shrink-0"
                        title="Remove from favorites"
                      >
                        <Heart className="w-5 h-5 fill-rose-400" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="p-5 bg-black/60 border-t border-white/10">
            <button
              onClick={onClose}
              className="w-full bg-white/10 hover:bg-white/20 text-white font-medium text-xs py-3 rounded-full transition-all cursor-pointer"
            >
              Close Favorites Window
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
