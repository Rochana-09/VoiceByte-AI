import React from 'react';
import { Mic, ShoppingBag, MapPin, Volume2, VolumeX, Heart, Bike } from 'lucide-react';

interface HeaderProps {
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
  isListening: boolean;
  isSpeaking: boolean;
  onToggleMic: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  currentAddress: string;
  onAddressClick: () => void;
  onOpenFavorites: () => void;
  favoritesCount?: number;
  hasActiveOrder?: boolean;
  onViewOrderTracker?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  cartTotal,
  onOpenCart,
  isListening,
  isSpeaking,
  onToggleMic,
  soundEnabled,
  onToggleSound,
  currentAddress,
  onAddressClick,
  onOpenFavorites,
  favoritesCount = 0,
  hasActiveOrder = false,
  onViewOrderTracker,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#050508]/80 backdrop-blur-xl border-b border-white/10 text-white px-4 lg:px-8 py-3.5 shadow-2xl transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Logo & Brand */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className={`w-9 h-9 rounded-full bg-gradient-to-tr from-emerald-400 to-blue-500 flex items-center justify-center shadow-[0_0_15px_rgba(16,185,129,0.5)] ${isListening || isSpeaking ? 'ring-2 ring-emerald-400 ring-offset-2 ring-offset-[#050508]' : ''}`}>
              <Mic className="w-4 h-4 text-black font-bold" />
            </div>
            {(isListening || isSpeaking) && (
              <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500"></span>
              </span>
            )}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-medium tracking-tight text-lg text-white">
                VoiceBite <span className="text-emerald-400 font-bold">AI</span>
              </span>
            </div>
            <p className="text-[11px] text-white/50 hidden sm:block">Voice Sensor Assistant</p>
          </div>
        </div>

        {/* Location Selector (Desktop & Mobile) */}
        <button
          onClick={onAddressClick}
          className="flex items-center gap-1.5 bg-white/5 hover:bg-white/10 text-white/80 px-3 sm:px-4 py-1.5 rounded-full border border-white/10 text-xs transition-all cursor-pointer max-w-[140px] sm:max-w-xs"
          title="Change delivery location"
        >
          <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span className="font-medium text-white/50 text-xs hidden md:inline">Deliver to:</span>
          <span className="truncate text-white font-medium text-xs">{currentAddress}</span>
        </button>

        {/* Voice Control & Cart Actions */}
        <div className="flex items-center gap-1.5 sm:gap-3">
          {/* Active Order Live Tracker Badge */}
          {hasActiveOrder && onViewOrderTracker && (
            <button
              onClick={onViewOrderTracker}
              className="flex items-center gap-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer animate-pulse"
              title="Track live delivery"
            >
              <Bike className="w-4 h-4 text-emerald-400" />
              <span className="hidden sm:inline">Track Food</span>
            </button>
          )}

          {/* Favorites Button */}
          <button
            onClick={onOpenFavorites}
            className="relative p-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-rose-400 transition-all cursor-pointer"
            title="View saved favorites"
          >
            <Heart className="w-4 h-4 fill-rose-400" />
            {favoritesCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {favoritesCount}
              </span>
            )}
          </button>

          {/* Audio Output Mute/Unmute */}
          <button
            onClick={onToggleSound}
            className={`p-2 rounded-full border transition-all text-xs flex items-center gap-1.5 ${
              soundEnabled
                ? 'bg-white/5 text-white/80 border-white/10 hover:bg-white/10'
                : 'bg-red-500/10 text-red-400 border-red-500/30 hover:bg-red-500/20'
            }`}
            title={soundEnabled ? 'AI Speech Sound Enabled' : 'AI Speech Muted'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden xl:inline text-xs">{soundEnabled ? 'Voice On' : 'Muted'}</span>
          </button>

          {/* Voice Sensor Mic Trigger */}
          <button
            onClick={onToggleMic}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
              isListening
                ? 'bg-emerald-500 text-black animate-pulse shadow-[0_0_20px_rgba(16,185,129,0.6)]'
                : 'bg-white/5 hover:bg-white/10 text-white border border-white/10'
            }`}
          >
            <Mic className={`w-4 h-4 ${isListening ? 'text-black animate-spin' : 'text-emerald-400'}`} />
            <span className="hidden sm:inline">{isListening ? 'Listening...' : 'Sensor Mic'}</span>
          </button>

          {/* Cart Button */}
          <button
            onClick={onOpenCart}
            className="relative flex items-center gap-2 bg-emerald-400 hover:bg-emerald-300 text-black font-semibold px-3.5 sm:px-4 py-2 rounded-full shadow-[0_0_20px_rgba(52,211,153,0.3)] transition-all cursor-pointer active:scale-95"
          >
            <ShoppingBag className="w-4 h-4 stroke-[2.5]" />
            <span className="text-xs sm:text-sm font-bold">
              {cartCount > 0 ? `₹${cartTotal}` : 'Cart'}
            </span>
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-black text-emerald-400 border border-emerald-400 text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
