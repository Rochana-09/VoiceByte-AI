import React, { useState } from 'react';
import { X, MapPin, Navigation, Check, Building2 } from 'lucide-react';

interface LocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentAddress: string;
  onSelectAddress: (address: string) => void;
}

const POPULAR_LOCATIONS = [
  { name: 'Indiranagar 100ft Road', city: 'Bangalore', fullAddress: '12th Main Rd, Indiranagar 100ft Rd, Bangalore - 560038' },
  { name: 'Koramangala 5th Block', city: 'Bangalore', fullAddress: '80 Feet Road, Koramangala 5th Block, Bangalore - 560095' },
  { name: 'HSR Layout Sector 1', city: 'Bangalore', fullAddress: '27th Main Rd, HSR Layout Sector 1, Bangalore - 560102' },
  { name: 'MG Road Metro Hub', city: 'Bangalore', fullAddress: 'Church Street & MG Road Crossing, Bangalore - 560001' },
  { name: 'Jubilee Hills Rd 36', city: 'Hyderabad', fullAddress: 'Road No. 36, Jubilee Hills, Hyderabad - 500033' },
  { name: 'Banjara Hills Rd 12', city: 'Hyderabad', fullAddress: 'Road No. 12, Banjara Hills, Hyderabad - 500034' },
];

export const LocationModal: React.FC<LocationModalProps> = ({
  isOpen,
  onClose,
  currentAddress,
  onSelectAddress,
}) => {
  const [customInput, setCustomInput] = useState('');
  const [isLocating, setIsLocating] = useState(false);

  if (!isOpen) return null;

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customInput.trim()) return;
    onSelectAddress(customInput.trim());
    onClose();
  };

  const handleDetectLocation = () => {
    setIsLocating(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setIsLocating(false);
          const detected = `Near ${pos.coords.latitude.toFixed(3)}, ${pos.coords.longitude.toFixed(3)} - Indiranagar 100ft Rd, Bangalore`;
          onSelectAddress(detected);
          onClose();
        },
        () => {
          setIsLocating(false);
          // Fallback location if permission denied or iframe restrictions apply
          onSelectAddress('Indiranagar 100ft Road, Bangalore');
          onClose();
        }
      );
    } else {
      setIsLocating(false);
      onSelectAddress('Indiranagar 100ft Road, Bangalore');
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#050508] border border-white/10 text-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl flex flex-col">
        {/* Modal Header */}
        <div className="p-5 bg-black/60 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-medium text-white">Change Delivery Address</h2>
              <p className="text-xs text-white/50">Select or type your delivery location</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-white/50 hover:text-white hover:bg-white/10 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Address & Auto Detect */}
        <div className="p-5 space-y-4">
          <button
            onClick={handleDetectLocation}
            disabled={isLocating}
            className="w-full flex items-center justify-between bg-emerald-500/10 border border-emerald-500/30 hover:bg-emerald-500/20 text-emerald-300 p-4 rounded-2xl transition-all text-xs font-semibold cursor-pointer group"
          >
            <div className="flex items-center gap-3">
              <Navigation className={`w-5 h-5 text-emerald-400 ${isLocating ? 'animate-spin' : 'group-hover:scale-110 transition-transform'}`} />
              <div className="text-left">
                <span className="block text-emerald-400 font-bold">Use Current Live GPS Location</span>
                <span className="text-[11px] text-emerald-300/70">Auto-detect nearest delivery hub</span>
              </div>
            </div>
            <span className="text-[10px] bg-emerald-400 text-black px-2.5 py-1 rounded-full font-bold">
              GPS
            </span>
          </button>

          {/* Custom Address Input */}
          <form onSubmit={handleCustomSubmit} className="space-y-2">
            <label className="block text-xs font-medium text-white/60 uppercase tracking-widest">
              Type Custom Address
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={customInput}
                onChange={(e) => setCustomInput(e.target.value)}
                placeholder="e.g. Flat 402, Embassy Heights, Koramangala"
                className="flex-1 bg-white/5 border border-white/10 focus:border-emerald-400 rounded-full px-4 py-2.5 text-xs text-white placeholder-white/30 outline-none"
              />
              <button
                type="submit"
                disabled={!customInput.trim()}
                className="bg-emerald-400 hover:bg-emerald-300 disabled:opacity-40 text-black font-semibold px-5 py-2.5 rounded-full text-xs transition-all cursor-pointer shrink-0"
              >
                Save
              </button>
            </div>
          </form>

          {/* Popular Delivery Hubs */}
          <div className="pt-2">
            <label className="block text-xs font-medium text-white/60 uppercase tracking-widest mb-2.5">
              Popular Delivery Locations
            </label>
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {POPULAR_LOCATIONS.map((loc, idx) => {
                const isSelected = currentAddress.includes(loc.name);
                return (
                  <button
                    key={idx}
                    onClick={() => {
                      onSelectAddress(loc.fullAddress);
                      onClose();
                    }}
                    className={`w-full text-left p-3.5 rounded-2xl border text-xs transition-all flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-500/10 border-emerald-400 text-white'
                        : 'bg-white/5 border-white/10 hover:bg-white/10 text-white/80'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <Building2 className={`w-4 h-4 mt-0.5 ${isSelected ? 'text-emerald-400' : 'text-white/40'}`} />
                      <div>
                        <span className="font-semibold text-white block">{loc.name}</span>
                        <span className="text-[11px] text-white/50">{loc.fullAddress}</span>
                      </div>
                    </div>
                    {isSelected && (
                      <Check className="w-4 h-4 text-emerald-400 stroke-[3] shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-black/60 border-t border-white/10 text-center text-[11px] text-white/40">
          Delivery address is updated live for AI voice orders and cart totals.
        </div>
      </div>
    </div>
  );
};
