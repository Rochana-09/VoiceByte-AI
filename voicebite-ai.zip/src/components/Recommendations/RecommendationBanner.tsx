import React from 'react';
import { Sparkles, RefreshCw, ChefHat, Heart, ChevronRight, MessageSquareCode } from 'lucide-react';
import { MenuItem } from '../../types/food';

interface RecommendationBannerProps {
  pastOrdersCount: number;
  userPreferences: {
    spiceLevel?: string;
    isVegOnly?: boolean;
    favoriteCategory?: string;
  };
  recommendedDishes: MenuItem[];
  onSelectDish: (dish: MenuItem) => void;
  onAnswerClarification: (answer: string) => void;
}

export const RecommendationBanner: React.FC<RecommendationBannerProps> = ({
  pastOrdersCount,
  userPreferences,
  recommendedDishes,
  onSelectDish,
  onAnswerClarification,
}) => {
  if (recommendedDishes.length === 0) return null;

  return (
    <div className="bg-gradient-to-r from-[#0a1210] via-[#050b10] to-[#050508] border border-emerald-500/20 rounded-3xl p-5 my-6 relative overflow-hidden shadow-2xl">
      {/* Background Accent glow */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 border-b border-white/10 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-emerald-400 text-black flex items-center justify-center font-bold shadow-[0_0_15px_rgba(52,211,153,0.4)]">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-semibold text-white">AI Personal Recommendation Engine</h3>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono">
                Learned from {pastOrdersCount || 3}+ orders
              </span>
            </div>
            <p className="text-xs text-white/50">
              Personalized based on your preference: <span className="text-emerald-300 font-medium">{userPreferences.spiceLevel || 'Medium Spice'} • {userPreferences.isVegOnly ? 'Pure Veg' : 'Chicken & Mutton Dum'}</span>
            </p>
          </div>
        </div>
      </div>

      {/* Clarifying Voice Question Prompt */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-3.5 mb-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-start gap-2.5">
          <MessageSquareCode className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <p className="text-xs text-white/90 leading-relaxed">
            <strong className="text-emerald-400">AI Clarifying Question:</strong> "I noticed you usually order Hyderabadi Dum Biryani! Would you like extra Mirchi Ka Salan or Raita with your dish today?"
          </p>
        </div>
        <div className="flex flex-wrap gap-2 shrink-0">
          <button
            onClick={() => onAnswerClarification('Yes, add extra Mirchi Ka Salan')}
            className="text-[11px] bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 px-3 py-1.5 rounded-full transition-all cursor-pointer"
          >
            + Add Salan (₹45)
          </button>
          <button
            onClick={() => onAnswerClarification('Make it extra spicy today')}
            className="text-[11px] bg-white/5 hover:bg-white/10 text-white/80 border border-white/10 px-3 py-1.5 rounded-full transition-all cursor-pointer"
          >
            Extra Spicy
          </button>
        </div>
      </div>

      {/* Recommended Items Horizontal Scroll */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {recommendedDishes.slice(0, 3).map((dish) => (
          <div
            key={dish.id}
            onClick={() => onSelectDish(dish)}
            className="bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl p-3 flex items-center gap-3 transition-all cursor-pointer group"
          >
            <img
              src={dish.image}
              alt={dish.name}
              className="w-16 h-16 rounded-xl object-cover shrink-0 group-hover:scale-105 transition-transform"
            />
            <div className="min-w-0 flex-1">
              <span className="text-[9px] bg-emerald-400/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider block w-fit mb-1">
                98% Taste Match
              </span>
              <h4 className="font-medium text-xs text-white truncate">{dish.name}</h4>
              <p className="text-[10px] text-white/50 truncate">{dish.restaurantName}</p>
              <div className="flex items-center justify-between mt-1">
                <span className="font-mono text-emerald-400 text-xs font-bold">₹{dish.price}</span>
                <span className="text-[10px] text-emerald-400 font-semibold group-hover:underline flex items-center gap-0.5">
                  Order <ChevronRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
