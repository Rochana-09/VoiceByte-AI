import React from 'react';
import { Flame, Utensils, Pizza, Hamburger, Soup, Leaf, Heart, Sparkles } from 'lucide-react';

interface CategoryPillsProps {
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  favoritesCount?: number;
}

export const CATEGORIES = [
  { id: 'all', label: 'All Cravings', icon: Utensils },
  { id: 'favorites', label: 'My Favorites', icon: Heart, badge: '❤️ Saved' },
  { id: 'recommendations', label: 'AI Recommends', icon: Sparkles, badge: '✨ For You' },
  { id: 'biryani', label: 'Biryani Specials', icon: Flame, badge: '🔥 Hot' },
  { id: 'pizza', label: 'Woodfired Pizza', icon: Pizza },
  { id: 'burger', label: 'Gourmet Burgers', icon: Hamburger },
  { id: 'chinese', label: 'Chinese & Asian', icon: Soup },
  { id: 'veg', label: 'Pure Veg Delights', icon: Leaf },
];

export const CategoryPills: React.FC<CategoryPillsProps> = ({
  selectedCategory,
  onSelectCategory,
}) => {
  return (
    <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-2 px-1">
      {CATEGORIES.map((cat) => {
        const Icon = cat.icon;
        const isSelected = selectedCategory === cat.id;

        return (
          <button
            key={cat.id}
            onClick={() => onSelectCategory(cat.id)}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-xs sm:text-sm font-medium transition-all whitespace-nowrap cursor-pointer shrink-0 ${
              isSelected
                ? 'bg-emerald-400 text-black font-semibold shadow-[0_0_15px_rgba(52,211,153,0.4)] scale-[1.02]'
                : 'bg-white/5 hover:bg-white/10 text-white/70 border border-white/10 hover:text-white'
            }`}
          >
            <Icon className={`w-4 h-4 ${isSelected ? 'text-black' : 'text-emerald-400'}`} />
            <span>{cat.label}</span>
            {cat.badge && (
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${isSelected ? 'bg-black text-emerald-400' : 'bg-emerald-500/10 text-emerald-400'}`}>
                {cat.badge}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
};
