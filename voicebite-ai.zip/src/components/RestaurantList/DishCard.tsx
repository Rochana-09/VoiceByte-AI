import React from 'react';
import { Star, Clock, Plus, Mic, Check, Heart } from 'lucide-react';
import { MenuItem } from '../../types/food';

interface DishCardProps {
  dish: MenuItem;
  onSelectDish: (dish: MenuItem) => void;
  isRecommended?: boolean;
  isFavorite?: boolean;
  onToggleFavorite?: (dishId: string) => void;
}

export const DishCard: React.FC<DishCardProps> = ({
  dish,
  onSelectDish,
  isRecommended = false,
  isFavorite = false,
  onToggleFavorite,
}) => {
  return (
    <div
      onClick={() => onSelectDish(dish)}
      className={`group relative bg-white/5 backdrop-blur-xl border rounded-3xl overflow-hidden transition-all duration-300 hover:bg-white/10 hover:-translate-y-1 flex flex-col justify-between cursor-pointer ${
        isRecommended
          ? 'border-emerald-500/50 ring-2 ring-emerald-500/30'
          : 'border-white/10 hover:border-white/20'
      }`}
    >
      {/* Dish Image Header */}
      <div className="relative h-48 w-full overflow-hidden bg-black/40">
        <img
          src={dish.image}
          alt={dish.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#050508] via-[#050508]/20 to-transparent" />

        {/* Veg / Non-Veg Indicator */}
        <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/10 flex items-center gap-1.5 text-[10px] font-bold tracking-widest uppercase">
          <span
            className={`w-2 h-2 rounded-full ${
              dish.isVeg ? 'bg-emerald-400' : 'bg-rose-400'
            }`}
          />
          <span className={dish.isVeg ? 'text-emerald-400' : 'text-rose-400'}>
            {dish.isVeg ? 'VEG' : 'NON-VEG'}
          </span>
        </div>

        {/* Favorite Heart Button & Recommended Badge */}
        <div className="absolute top-3 right-3 flex items-center gap-1.5">
          {onToggleFavorite && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleFavorite(dish.id);
              }}
              className="w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md border border-white/10 flex items-center justify-center transition-all cursor-pointer group/btn"
              title={isFavorite ? 'Remove from favorites' : 'Save to favorites'}
            >
              <Heart
                className={`w-4 h-4 transition-transform group-hover/btn:scale-110 ${
                  isFavorite ? 'text-rose-400 fill-rose-400' : 'text-white/70 hover:text-white'
                }`}
              />
            </button>
          )}

          {isRecommended && (
            <div className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-3 py-1 rounded-full text-[10px] font-bold tracking-widest uppercase shadow-md flex items-center gap-1">
              <Mic className="w-3 h-3 text-emerald-400" />
              <span>AI Choice</span>
            </div>
          )}
        </div>

        {/* Restaurant Name Tag */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-white/70">
          <span className="font-medium text-white truncate max-w-[70%]">
            {dish.restaurantName}
          </span>
          <span className="flex items-center gap-1 bg-black/60 backdrop-blur-md px-2.5 py-0.5 rounded-full text-emerald-400 font-medium text-[11px] border border-white/10">
            <Clock className="w-3 h-3 text-emerald-400" />
            {dish.preparationTime}
          </span>
        </div>
      </div>

      {/* Dish Details */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-start justify-between gap-2 mb-1.5">
            <h3 className="font-medium text-lg text-white group-hover:text-emerald-400 transition-colors leading-snug">
              {dish.name}
            </h3>
            <div className="flex items-center gap-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-2.5 py-0.5 rounded-full text-xs font-bold shrink-0">
              <Star className="w-3 h-3 fill-emerald-400 text-emerald-400" />
              <span>{dish.rating}</span>
            </div>
          </div>

          <p className="text-xs text-white/50 line-clamp-2 mb-3 leading-relaxed">
            {dish.description}
          </p>

          {/* Tags */}
          <div className="flex flex-wrap gap-1.5 mb-4">
            {dish.tags.map((tag, idx) => (
              <span
                key={idx}
                className="text-[10px] bg-white/5 text-white/60 px-2.5 py-0.5 rounded-full border border-white/10"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Price & Action Button */}
        <div className="pt-3 border-t border-white/10 flex items-center justify-between">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-lg font-mono text-emerald-400 font-bold">₹{dish.price}</span>
              {dish.originalPrice && (
                <span className="text-xs text-white/30 line-through">₹{dish.originalPrice}</span>
              )}
            </div>
            <span className="text-[10px] text-white/40 block">Taxes included</span>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onSelectDish(dish);
            }}
            className="w-9 h-9 rounded-full bg-emerald-400 hover:bg-emerald-300 text-black flex items-center justify-center transition-all shadow-[0_0_15px_rgba(52,211,153,0.3)] cursor-pointer group-hover:scale-105"
            title="Customize & Add"
          >
            <Plus className="w-5 h-5 stroke-[2.5]" />
          </button>
        </div>
      </div>
    </div>
  );
};
