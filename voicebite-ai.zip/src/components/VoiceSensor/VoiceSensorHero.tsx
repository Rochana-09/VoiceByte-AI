import React, { useState } from 'react';
import { Mic, MicOff, Sparkles, Volume2, Send, Flame, Radio, Globe, Bot, Check, ArrowRight } from 'lucide-react';
import { VoiceMessage } from '../../types/food';
import { voiceService } from '../../services/voiceService';

interface VoiceSensorHeroProps {
  isListening: boolean;
  isSpeaking: boolean;
  transcript: string;
  onStartListening: () => void;
  onStopListening: () => void;
  onSendTextQuery: (text: string) => void;
  conversation: VoiceMessage[];
  suggestedActions: string[];
  activeFilter: string;
  voiceVolume?: number;
  hasStarted?: boolean;
  isThinking?: boolean;
  thinkingSteps?: string[];
}

export const VoiceSensorHero: React.FC<VoiceSensorHeroProps> = ({
  isListening,
  isSpeaking,
  transcript,
  onStartListening,
  onStopListening,
  onSendTextQuery,
  conversation,
  suggestedActions,
  activeFilter,
  voiceVolume = 0,
  hasStarted = false,
  isThinking = false,
  thinkingSteps = [],
}) => {
  const [inputText, setInputText] = useState('');
  const [showSecondaryTyping, setShowSecondaryTyping] = useState(false);
  const [currentLang, setCurrentLang] = useState(voiceService.getLanguage());

  const SAMPLE_CRAVINGS = [
    "I'm feeling hungry, I want to have biryani",
    "Show me the best Hyderabadi Biryani spots",
    "I want spicy boneless chicken biryani",
    "Find woodfired sourdough pizza nearby",
    "Where is my food delivery status?",
  ];

  const handleLanguageChange = (lang: string) => {
    setCurrentLang(lang);
    voiceService.setLanguage(lang);
  };

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendTextQuery(inputText.trim());
    setInputText('');
  };

  const latestAiMessage = [...conversation].reverse().find((m) => m.sender === 'ai');
  const latestUserMessage = [...conversation].reverse().find((m) => m.sender === 'user');

  return (
    <div className="relative overflow-hidden bg-[#050508] text-white pt-6 pb-10 px-4 lg:px-8 border-b border-white/10">
      {/* Background Atmosphere Orbs */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[45%] h-[45%] bg-blue-900/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[45%] h-[45%] bg-emerald-900/20 rounded-full blur-[120px]" />
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        {/* SIMPLIFIED INITIAL FIRST SCREEN (Voice-First & Reduced Cognitive Load) */}
        {!hasStarted && !isListening && (
          <div className="bg-[#121217] border border-white/10 rounded-3xl p-6 sm:p-8 my-4 shadow-2xl relative overflow-hidden animate-fadeIn">
            {/* Ambient Corner Glow */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

            {/* Header Robot Icon + Product Headline */}
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-bold text-xl shadow-[0_0_15px_rgba(52,211,153,0.3)] shrink-0">
                🤖
              </div>
              <div>
                <h2 className="text-2xl sm:text-3xl font-semibold text-white tracking-tight">
                  Just speak. I'll handle the rest.
                </h2>
                <p className="text-xs sm:text-sm text-emerald-400/90 font-medium mt-0.5">
                  Find food, compare options, and order—all through a natural conversation.
                </p>
              </div>
            </div>

            {/* Warm Human Greeting */}
            <div className="my-5 bg-white/5 border border-white/10 p-4 rounded-2xl">
              <p className="text-sm text-white/90 leading-relaxed">
                👋 <span className="font-medium text-white">Hey! Feeling hungry?</span> Tell me what you're craving and I'll take care of the rest.
              </p>
            </div>

            {/* VOICE IS THE STAR: Single Prominent Tap to Speak Bar */}
            <div className="space-y-4">
              <button
                onClick={onStartListening}
                className="w-full bg-gradient-to-r from-emerald-400 via-emerald-500 to-teal-400 hover:from-emerald-300 hover:to-teal-300 text-black font-extrabold text-base py-4 rounded-2xl shadow-[0_0_35px_rgba(52,211,153,0.4)] flex items-center justify-center gap-3 transition-all cursor-pointer active:scale-[0.98] group"
              >
                <div className="w-8 h-8 rounded-full bg-black/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Mic className="w-5 h-5 stroke-[2.5] text-black" />
                </div>
                <span>Tap to Speak</span>
              </button>

              {/* Secondary Option: Prefer typing? Type here... */}
              <div className="text-center">
                {!showSecondaryTyping ? (
                  <button
                    onClick={() => setShowSecondaryTyping(true)}
                    className="text-xs text-white/50 hover:text-emerald-400 transition-colors cursor-pointer py-1 underline underline-offset-4"
                  >
                    Prefer typing? Type here...
                  </button>
                ) : (
                  <form onSubmit={handleTextSubmit} className="flex items-center gap-2 animate-fadeIn pt-1">
                    <input
                      type="text"
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      placeholder="Prefer typing? Type your craving here..."
                      className="flex-1 bg-black/50 border border-white/20 focus:border-emerald-400 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder-white/40 outline-none transition-all"
                      autoFocus
                    />
                    <button
                      type="submit"
                      disabled={!inputText.trim()}
                      className="bg-emerald-400 hover:bg-emerald-300 text-black font-bold px-4 py-2.5 rounded-xl text-xs transition-all cursor-pointer disabled:opacity-30"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                )}
              </div>
            </div>

            {/* Quick Prompts */}
            <div className="mt-6 pt-4 border-t border-white/10 flex flex-wrap items-center gap-2">
              <span className="text-[11px] text-white/40 font-medium">Or try saying:</span>
              {SAMPLE_CRAVINGS.slice(0, 3).map((craving, idx) => (
                <button
                  key={idx}
                  onClick={() => onSendTextQuery(craving)}
                  className="text-xs bg-white/5 hover:bg-emerald-500/10 text-white/70 hover:text-emerald-300 px-3 py-1 rounded-full border border-white/10 hover:border-emerald-500/30 transition-all cursor-pointer"
                >
                  "{craving}"
                </button>
              ))}
            </div>
          </div>
        )}

        {/* FULL CONVERSATION & SENSOR CONTROLS (Appears after interaction starts or when mic active) */}
        {(hasStarted || isListening) && (
          <div className="space-y-4 animate-fadeIn">
            {/* Header Badge & Language Accent Switcher */}
            <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-emerald-400">
                <Radio className={`w-3.5 h-3.5 ${isListening || isSpeaking ? 'text-emerald-400 animate-pulse' : 'text-white/40'}`} />
                <span>Voice Sensor: {isListening ? 'Listening to Mic...' : isSpeaking ? 'AI Speaking...' : 'Active'}</span>
              </div>

              {/* Accent / Speech Language Switcher */}
              <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-3 py-1 text-xs">
                <Globe className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-white/50 text-[11px]">Speech Accent:</span>
                <div className="flex items-center gap-1">
                  {[
                    { code: 'en-IN', label: 'English (India)' },
                    { code: 'en-US', label: 'English (US)' },
                    { code: 'hi-IN', label: 'Hindi / Hinglish' },
                  ].map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => handleLanguageChange(lang.code)}
                      className={`px-2 py-0.5 rounded-full text-[10px] font-medium transition-all cursor-pointer ${
                        currentLang === lang.code
                          ? 'bg-emerald-400 text-black font-bold'
                          : 'text-white/60 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      {lang.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Central Voice Sensor Orb */}
            <div className="flex flex-col items-center text-center my-2">
              <div className="relative flex items-center justify-center my-2">
                <div
                  className={`absolute w-56 h-56 border border-emerald-500/20 rounded-full transition-transform duration-700 ${
                    isListening || isSpeaking ? 'scale-125 border-emerald-400/40 animate-pulse' : 'scale-100'
                  }`}
                />
                <button
                  onClick={isListening ? onStopListening : onStartListening}
                  className={`relative w-28 h-28 rounded-full bg-gradient-to-b from-emerald-400 to-emerald-600 shadow-[0_0_60px_rgba(52,211,153,0.4)] flex flex-col items-center justify-center cursor-pointer transition-all duration-300 hover:scale-105 active:scale-95 ${
                    isListening ? 'ring-4 ring-emerald-300 ring-offset-4 ring-offset-[#050508] scale-110' : ''
                  }`}
                >
                  <div className="flex gap-1 items-end mb-1">
                    {[20, 40, 70, 90, 50, 80, 30].map((baseHeight, i) => {
                      const calculatedHeight = isListening
                        ? Math.max(8, Math.min(40, Math.round((voiceVolume / 100) * baseHeight * 1.5)))
                        : baseHeight / 2;
                      return (
                        <div
                          key={i}
                          style={{ height: `${calculatedHeight}px` }}
                          className={`w-1 rounded-full bg-black/90 transition-all duration-75 ${
                            isListening ? 'bg-black' : 'bg-black/50'
                          }`}
                        />
                      );
                    })}
                  </div>
                  <span className="text-[10px] font-bold tracking-wider text-black uppercase">
                    {isListening ? 'Listening...' : isSpeaking ? 'Speaking' : 'Tap & Speak'}
                  </span>
                </button>
              </div>

              {/* Live Voice Stream / Volume Indicator (Screenshot 2 Match) */}
              {isListening && (
                <div className="w-full max-w-lg mt-3 bg-[#121217] border border-emerald-500/50 rounded-2xl p-4 shadow-2xl animate-fadeIn space-y-1.5 text-left">
                  <div className="flex items-center justify-between text-xs font-semibold text-emerald-400">
                    <div className="flex items-center gap-2">
                      <Mic className="w-4 h-4 animate-bounce text-emerald-400" />
                      <span>Listening...</span>
                    </div>
                    <div className="text-[10px] text-white/40">Mic level: {voiceVolume}%</div>
                  </div>
                  <p className="text-sm font-medium text-white italic pl-6">
                    "{transcript || "I'm listening... tell me what you're craving"}"
                  </p>
                </div>
              )}
            </div>

            {/* LIVE THINKING ANIMATION STEPS CARD (Screenshot 2 Match) */}
            {isThinking && (
              <div className="bg-[#121217] border border-emerald-500/50 rounded-2xl p-4 sm:p-5 space-y-3 shadow-2xl animate-fadeIn my-4 text-left">
                <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
                  <Bot className="w-4 h-4 text-emerald-400 animate-spin" />
                  <span>Thinking...</span>
                </div>
                <div className="space-y-2 pl-6">
                  {thinkingSteps.map((step, idx) => (
                    <div key={idx} className="flex items-center gap-2.5 text-xs text-white/90 animate-fadeIn">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                      <span className="font-mono text-emerald-200">{step}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* AI Conversation Dialogue Box */}
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-5 shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs font-semibold uppercase tracking-widest text-white/60">Voice Assistant Dialogue</span>
                </div>
                {activeFilter !== 'all' && (
                  <span className="text-xs px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-medium">
                    Filtered: {activeFilter.toUpperCase()}
                  </span>
                )}
              </div>

              <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
                {conversation.map((msg) => (
                  <div key={msg.id}>
                    {msg.sender === 'user' ? (
                      <div className="flex items-start gap-3 justify-end">
                        <div className="bg-emerald-500/20 border border-emerald-500/30 text-white rounded-3xl rounded-tr-none px-4 py-2.5 max-w-[85%] text-xs shadow-md">
                          <div className="text-[9px] text-emerald-400 font-semibold mb-0.5">You (Voice)</div>
                          <p className="font-medium">{msg.text}</p>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-400 to-blue-500 text-black font-bold text-xs flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(16,185,129,0.5)]">
                          AI
                        </div>
                        <div className="bg-white/5 border border-white/10 text-white rounded-3xl rounded-tl-none px-4 py-2.5 max-w-[85%] text-xs shadow-md">
                          <div className="text-[9px] text-emerald-400 font-semibold mb-0.5 flex items-center gap-1">
                            <Sparkles className="w-3 h-3" /> VoiceBite Concierge
                          </div>
                          <p className="leading-relaxed text-white/90">{msg.text}</p>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* AI Suggested Action Chips */}
              {suggestedActions.length > 0 && (
                <div className="pt-3 border-t border-white/10">
                  <div className="text-xs text-white/40 font-medium mb-2">Voice Quick Suggestions:</div>
                  <div className="flex flex-wrap gap-2">
                    {suggestedActions.map((action, idx) => (
                      <button
                        key={idx}
                        onClick={() => onSendTextQuery(action)}
                        className="text-xs bg-white/5 hover:bg-emerald-500/20 text-emerald-300 hover:text-emerald-200 border border-white/10 hover:border-emerald-500/40 px-3.5 py-1.5 rounded-full transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <Mic className="w-3 h-3 text-emerald-400" />
                        <span>"{action}"</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Input Bar */}
              <form onSubmit={handleTextSubmit} className="pt-2 flex items-center gap-2">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Type your craving or command..."
                  className="flex-1 bg-black/40 border border-white/10 focus:border-emerald-400/80 rounded-full px-5 py-2 text-xs text-white placeholder-white/30 outline-none transition-all"
                />
                <button
                  type="submit"
                  disabled={!inputText.trim()}
                  className="bg-emerald-400 hover:bg-emerald-300 disabled:opacity-40 text-black font-semibold px-5 py-2 rounded-full text-xs transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>Send</span>
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};


