import { MenuItem, Restaurant, DeliveryPartner } from '../types/food';

export const RESTAURANTS: Restaurant[] = [
  {
    id: 'rest-1',
    name: 'Paradise Biryani Palace',
    cuisine: ['Hyderabadi', 'Biryani', 'Mughlai'],
    rating: 4.8,
    reviews: '12.4k+ ratings',
    deliveryTime: '20-25 mins',
    distance: '1.8 km',
    priceForTwo: 550,
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80',
    address: 'Indiranagar 100ft Road, Bangalore',
    featuredDish: 'Hyderabadi Dum Chicken Biryani',
    badge: '👑 Best Biryani in City'
  },
  {
    id: 'rest-2',
    name: 'Bawarchi Royal Dum House',
    cuisine: ['Biryani', 'North Indian', 'Kebabs'],
    rating: 4.7,
    reviews: '8.9k+ ratings',
    deliveryTime: '25-30 mins',
    distance: '2.5 km',
    priceForTwo: 500,
    image: 'https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=800&q=80',
    address: 'Koramangala 5th Block, Bangalore',
    featuredDish: 'Mutton Special Dum Biryani',
    badge: '🔥 Trending Choice'
  },
  {
    id: 'rest-3',
    name: 'Behrouz Royal Biryani',
    cuisine: ['Persian Biryani', 'Kebabs', 'Desserts'],
    rating: 4.9,
    reviews: '15.1k+ ratings',
    deliveryTime: '30-35 mins',
    distance: '3.2 km',
    priceForTwo: 700,
    image: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80',
    address: 'MG Road Metro Station, Bangalore',
    featuredDish: 'Subz-E-Biryani & Boneless Dum Biryani',
    badge: '✨ Royal Gourmet'
  },
  {
    id: 'rest-4',
    name: 'Meghana Foods Express',
    cuisine: ['Andhra Biryani', 'South Indian', 'Spicy'],
    rating: 4.8,
    reviews: '22k+ ratings',
    deliveryTime: '18-22 mins',
    distance: '1.2 km',
    priceForTwo: 600,
    image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80',
    address: 'Jayanagar 4th Block, Bangalore',
    featuredDish: 'Meghana Boneless Chicken Biryani',
    badge: '🌶️ Authentic Andhra Spice'
  },
  {
    id: 'rest-5',
    name: 'Napoli Pizza Craft',
    cuisine: ['Italian', 'Woodfired Pizza', 'Pasta'],
    rating: 4.6,
    reviews: '5.2k+ ratings',
    deliveryTime: '25-30 mins',
    distance: '2.1 km',
    priceForTwo: 650,
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80',
    address: 'Church Street, Bangalore',
    featuredDish: 'Truffle Mushroom & Pepperoni Pizza',
  },
  {
    id: 'rest-6',
    name: 'Dragon Wok Asian Kitchen',
    cuisine: ['Chinese', 'Pan-Asian', 'Dim Sum'],
    rating: 4.5,
    reviews: '4.1k+ ratings',
    deliveryTime: '20-25 mins',
    distance: '1.9 km',
    priceForTwo: 550,
    image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=800&q=80',
    address: 'HSR Layout Sector 1, Bangalore',
    featuredDish: 'Chilli Garlic Noodles & Dumplings',
  }
];

export const MENU_ITEMS: MenuItem[] = [
  // Biryanis
  {
    id: 'dish-1',
    name: 'Hyderabadi Chicken Dum Biryani',
    restaurantId: 'rest-1',
    restaurantName: 'Paradise Biryani Palace',
    description: 'Slow-cooked succulent chicken pieces layered with fragrant basmati rice, saffron, caramelised onions, served with Mirchi Ka Salan and Raita.',
    price: 349,
    originalPrice: 399,
    rating: 4.9,
    reviewCount: 3420,
    isVeg: false,
    category: 'biryani',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80',
    preparationTime: '15 mins',
    tags: ['Best Seller', 'Hyderabadi', 'Chef Choice'],
    bestseller: true,
    customizations: {
      sizes: [
        { name: 'Half Portion (1 person)', price: 0 },
        { name: 'Full Jumbo Portion (2 persons)', price: 180 },
        { name: 'Family Bucket (4 persons)', price: 450 }
      ],
      spiceLevels: ['Mild', 'Medium Spicy', 'Extra Hyderabadi Spicy'],
      addOns: [
        { name: 'Extra Creamy Raita', price: 35 },
        { name: 'Mirchi Ka Salan', price: 45 },
        { name: 'Double Masala Egg', price: 40 },
        { name: 'Gulab Jamun (2 pcs)', price: 60 }
      ]
    }
  },
  {
    id: 'dish-2',
    name: 'Special Boneless Chicken Biryani',
    restaurantId: 'rest-4',
    restaurantName: 'Meghana Foods Express',
    description: 'Tender juicy boneless chicken stir-fried in authentic Andhra spices layered over aromatic ghee basmati rice. Famous regional specialty!',
    price: 369,
    originalPrice: 420,
    rating: 4.8,
    reviewCount: 5120,
    isVeg: false,
    category: 'biryani',
    image: 'https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=800&q=80',
    preparationTime: '18 mins',
    tags: ['Andhra Style', 'Boneless', 'Spicy Favorite'],
    bestseller: true,
    customizations: {
      sizes: [
        { name: 'Regular Box', price: 0 },
        { name: 'Large Feast Box', price: 200 }
      ],
      spiceLevels: ['Andhra Medium', 'Andhra Hot & Fiery'],
      addOns: [
        { name: 'Chicken 65 Side', price: 160 },
        { name: 'Extra Ghee Drizzle', price: 30 }
      ]
    }
  },
  {
    id: 'dish-3',
    name: 'Royal Mutton Dum Biryani',
    restaurantId: 'rest-2',
    restaurantName: 'Bawarchi Royal Dum House',
    description: 'Melt-in-mouth tender goat meat slow dum-cooked in authentic handi with shahi zafran and whole hand-ground spices.',
    price: 449,
    originalPrice: 499,
    rating: 4.9,
    reviewCount: 2890,
    isVeg: false,
    category: 'biryani',
    image: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80',
    preparationTime: '20 mins',
    tags: ['Royal Recipe', 'Mutton Special', 'Gourmet'],
    bestseller: true,
    customizations: {
      sizes: [
        { name: 'Single Royal Handi', price: 0 },
        { name: 'Double Royal Handi', price: 240 }
      ],
      spiceLevels: ['Mild Shahi', 'Medium Spiced'],
      addOns: [
        { name: 'Mutton Shami Kebab (2 pcs)', price: 180 },
        { name: 'Shahi Tukda Dessert', price: 85 }
      ]
    }
  },
  {
    id: 'dish-4',
    name: 'Paneer Tikka Dum Biryani (Veg)',
    restaurantId: 'rest-3',
    restaurantName: 'Behrouz Royal Biryani',
    description: 'Char-grilled cottage cheese cubes marinated in tandoori spices, layered with saffron basmati rice and roasted cashew nuts.',
    price: 319,
    originalPrice: 350,
    rating: 4.7,
    reviewCount: 1980,
    isVeg: true,
    category: 'biryani',
    image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80',
    preparationTime: '15 mins',
    tags: ['Pure Veg', 'Paneer Special', 'Nutty Flavor'],
    bestseller: false,
    customizations: {
      sizes: [
        { name: 'Regular Bowl', price: 0 },
        { name: 'King Bowl', price: 150 }
      ],
      spiceLevels: ['Mild', 'Medium', 'Spicy'],
      addOns: [
        { name: 'Extra Roasted Cashews', price: 40 },
        { name: 'Mint Raita', price: 30 }
      ]
    }
  },
  {
    id: 'dish-5',
    name: 'Egg Dum Biryani',
    restaurantId: 'rest-1',
    restaurantName: 'Paradise Biryani Palace',
    description: 'Boiled eggs pan-fried with roasted cumin and turmeric, layered over slow-cooked Biryani rice.',
    price: 269,
    rating: 4.6,
    reviewCount: 1450,
    isVeg: false,
    category: 'biryani',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80',
    preparationTime: '12 mins',
    tags: ['High Protein', 'Budget Friendly'],
  },

  // Other items (Pizza, Burgers, Asian)
  {
    id: 'dish-6',
    name: 'Woodfired Truffle Mushroom Pizza',
    restaurantId: 'rest-5',
    restaurantName: 'Napoli Pizza Craft',
    description: 'Hand-stretched sourdough base, truffle cream sauce, wild shiitake mushrooms, fresh mozzarella & fresh basil.',
    price: 499,
    rating: 4.8,
    reviewCount: 980,
    isVeg: true,
    category: 'pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80',
    preparationTime: '20 mins',
    tags: ['Sourdough', 'Italian Classic'],
  },
  {
    id: 'dish-7',
    name: 'Double Smoky Bacon Beef Burger',
    restaurantId: 'rest-5',
    restaurantName: 'Napoli Pizza Craft',
    description: 'Smash patties, aged cheddar cheese, crispy bacon, caramelized onion jam on a buttery brioche bun.',
    price: 389,
    rating: 4.7,
    reviewCount: 1200,
    isVeg: false,
    category: 'burger',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80',
    preparationTime: '15 mins',
    tags: ['Gourmet Burger', 'Cheesy'],
  },
  {
    id: 'dish-8',
    name: 'Schezwan Chilli Garlic Noodles',
    restaurantId: 'rest-6',
    restaurantName: 'Dragon Wok Asian Kitchen',
    description: 'Wok-tossed hakka noodles in house Schezwan sauce with bell peppers, crunchy scallions & roasted chilli garlic.',
    price: 279,
    rating: 4.6,
    reviewCount: 890,
    isVeg: true,
    category: 'chinese',
    image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=800&q=80',
    preparationTime: '14 mins',
    tags: ['Spicy Wok', 'Comfort Food'],
  }
];

export const DEFAULT_DELIVERY_PARTNER: DeliveryPartner = {
  name: 'Rahul Kumar',
  phone: '+91 98765 43210',
  rating: 4.9,
  trips: 1420,
  vehicle: 'Ather 450X Electric Scooter',
  vehicleNumber: 'KA 03 EV 8819',
  photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'
};
