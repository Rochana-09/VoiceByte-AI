import { VoiceMessage } from '../types/food';

export interface ChatApiResponse {
  spokenResponse: string;
  intent: 'RECOMMEND_FOOD' | 'CUSTOMIZE_ITEM' | 'ADD_TO_CART' | 'PROCEED_TO_CHECKOUT' | 'DELIVERY_STATUS' | 'FAVORITE_SHOW' | 'FAVORITE_ADD' | 'ORDER_USUAL' | 'CHANGE_LOCATION' | 'GENERAL_QUERY';
  filterKeyword?: string;
  newLocation?: string;
  recommendedItems?: string[];
  suggestedActions: string[];
}

export async function sendVoiceMessageToAI(
  userText: string,
  context: {
    activeFilter?: string;
    cartCount?: number;
    currentScreen?: string;
    address?: string;
    pastOrdersCount?: number;
    preferences?: any;
  }
): Promise<ChatApiResponse> {
  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userMessage: userText,
        context,
      }),
    });

    if (!res.ok) {
      throw new Error(`HTTP error ${res.status}`);
    }

    const data: ChatApiResponse = await res.json();
    return data;
  } catch (err) {
    console.warn('API Error, falling back locally:', err);
    
    // Smart local fallback parser
    const lower = userText.toLowerCase();

    if (lower.includes('favorite') || lower.includes('favourite')) {
      return {
        spokenResponse: "Here are your saved favorite dishes and restaurants! You can re-order your usual items anytime.",
        intent: 'FAVORITE_SHOW',
        filterKeyword: 'favorites',
        suggestedActions: ['Order My Usual', 'Hyderabadi Chicken Biryani', 'View Favorites']
      };
    }

    if (lower.includes('usual') || lower.includes('reorder')) {
      return {
        spokenResponse: "Adding your usual favorite Hyderabadi Dum Biryani to your cart now!",
        intent: 'ORDER_USUAL',
        suggestedActions: ['Checkout Now', 'Add Extra Raita', 'Change Location']
      };
    }

    if (lower.includes('where') || lower.includes('status') || lower.includes('arrive') || lower.includes('delivery') || lower.includes('food')) {
      return {
        spokenResponse: "Your delivery partner Rahul is currently on the way with your order! ETA is approximately 18 minutes.",
        intent: 'DELIVERY_STATUS',
        suggestedActions: ['Call Delivery Partner', 'View Live Map', 'Change Address']
      };
    }

    if (lower.includes('location') || lower.includes('address') || lower.includes('deliver to')) {
      return {
        spokenResponse: "Opening the location selector for you. Choose or type your new delivery address!",
        intent: 'CHANGE_LOCATION',
        suggestedActions: ['Indiranagar 100ft Rd', 'Koramangala 5th Block', 'HSR Layout']
      };
    }

    let filterKeyword = 'biryani';
    let spoken = "I hear you! I've filtered the top Biryani dishes for you. Paradise Biryani and Meghana Boneless Biryani are hot favorites!";

    if (lower.includes('pizza')) {
      filterKeyword = 'pizza';
      spoken = "Craving pizza? Check out Napoli Pizza Craft's Woodfired Truffle Mushroom Pizza!";
    } else if (lower.includes('burger')) {
      filterKeyword = 'burger';
      spoken = "Here are our juicy burgers! The Double Smoky Bacon Beef Burger is highly rated.";
    } else if (lower.includes('noodle') || lower.includes('chinese')) {
      filterKeyword = 'chinese';
      spoken = "Craving Chinese? Dragon Wok's Schezwan Chilli Garlic Noodles are spicy and delicious!";
    } else if (lower.includes('checkout') || lower.includes('pay') || lower.includes('order')) {
      return {
        spokenResponse: "I've reviewed your cart and delivery details! Tap 'Proceed to Secure Payment' when you're ready.",
        intent: 'PROCEED_TO_CHECKOUT',
        suggestedActions: ['Open Checkout', 'Add More Items', 'View Delivery Address']
      };
    }

    return {
      spokenResponse: spoken,
      intent: 'RECOMMEND_FOOD',
      filterKeyword,
      suggestedActions: ['Hyderabadi Dum Biryani', 'Special Boneless Biryani', 'View Cart']
    };
  }
}
