// Voice Service using Web Speech API (SpeechRecognition & SpeechSynthesis) + Web Audio API Analyser

export interface VoiceRecognitionHandlers {
  onStart?: () => void;
  onResult?: (transcript: string, isFinal: boolean) => void;
  onError?: (error: string) => void;
  onEnd?: () => void;
  onVolumeChange?: (volume: number) => void;
}

class VoiceService {
  private recognition: any = null;
  private synthesis: SpeechSynthesis | null = typeof window !== 'undefined' ? window.speechSynthesis : null;
  private isListening: boolean = false;
  private isSpeaking: boolean = false;
  private activeUtterance: SpeechSynthesisUtterance | null = null;
  private currentLanguage: string = 'en-IN'; // Default to Indian English for Indian food terms
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private volumeInterval: any = null;

  constructor() {
    this.initRecognition();
  }

  public setLanguage(lang: string) {
    this.currentLanguage = lang;
    if (this.recognition) {
      this.recognition.lang = lang;
    }
  }

  public getLanguage(): string {
    return this.currentLanguage;
  }

  private initRecognition() {
    if (typeof window === 'undefined') return;

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      try {
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = false;
        this.recognition.interimResults = true;
        this.recognition.lang = this.currentLanguage;
      } catch (err) {
        console.warn('SpeechRecognition initialization error:', err);
      }
    }
  }

  public isSupported(): boolean {
    if (typeof window === 'undefined') return false;
    return !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
  }

  public async requestMicPermission(): Promise<{ success: boolean; stream?: MediaStream; error?: string }> {
    if (typeof navigator !== 'undefined' && navigator.mediaDevices?.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        return { success: true, stream };
      } catch (err: any) {
        console.warn('Microphone permission denied or unsupported:', err);
        return { success: false, error: err?.name || 'PermissionDenied' };
      }
    }
    return { success: false, error: 'NotSupported' };
  }

  private startVolumeAnalyzer(stream: MediaStream, onVolumeChange?: (vol: number) => void) {
    try {
      this.stopVolumeAnalyzer();
      this.mediaStream = stream;
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;

      this.audioContext = new AudioCtx();
      const source = this.audioContext.createMediaStreamSource(stream);
      const analyser = this.audioContext.createAnalyser();
      analyser.fftSize = 64;
      source.connect(analyser);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);

      this.volumeInterval = setInterval(() => {
        analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const average = sum / dataArray.length;
        const normalizedVolume = Math.min(100, Math.round((average / 128) * 100));
        onVolumeChange?.(normalizedVolume);
      }, 100);
    } catch (e) {
      console.warn('Volume analyzer error:', e);
    }
  }

  private stopVolumeAnalyzer() {
    if (this.volumeInterval) {
      clearInterval(this.volumeInterval);
      this.volumeInterval = null;
    }
    if (this.audioContext) {
      this.audioContext.close().catch(() => {});
      this.audioContext = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }
  }

  public async startListening(handlers: VoiceRecognitionHandlers) {
    if (this.isSpeaking) {
      this.stopSpeaking();
    }

    this.stopListening();

    if (!this.recognition) {
      this.initRecognition();
    }

    if (!this.recognition) {
      handlers.onError?.('Speech recognition is not supported in this browser. Please use Google Chrome, Edge, or Apple Safari.');
      return;
    }

    // 1. Request microphone audio stream
    const micRes = await this.requestMicPermission();
    if (micRes.success && micRes.stream) {
      this.startVolumeAnalyzer(micRes.stream, handlers.onVolumeChange);
    }

    // Ensure language is set
    this.recognition.lang = this.currentLanguage;

    try {
      this.recognition.onstart = () => {
        this.isListening = true;
        handlers.onStart?.();
      };

      this.recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
          } else {
            interimTranscript += transcript;
          }
        }

        const currentText = finalTranscript || interimTranscript;
        if (currentText) {
          handlers.onResult?.(currentText, !!finalTranscript);
        }
      };

      this.recognition.onerror = (event: any) => {
        this.isListening = false;
        this.stopVolumeAnalyzer();
        const errType = event.error || 'Unknown voice error';
        console.warn('Voice recognition error:', errType);
        
        let friendlyMsg = errType;
        if (errType === 'not-allowed' || errType === 'permission-denied') {
          friendlyMsg = 'Microphone permission blocked. Please allow mic access in your browser or use the quick voice chips!';
        } else if (errType === 'no-speech') {
          friendlyMsg = 'No speech heard. Please speak clearly into your microphone or click a sample prompt!';
        } else if (errType === 'audio-capture') {
          friendlyMsg = 'No microphone detected. Please plug in a mic or use text bar!';
        }

        handlers.onError?.(friendlyMsg);
      };

      this.recognition.onend = () => {
        this.isListening = false;
        this.stopVolumeAnalyzer();
        handlers.onEnd?.();
      };

      this.recognition.start();
    } catch (err: any) {
      this.isListening = false;
      this.stopVolumeAnalyzer();
      handlers.onError?.(err?.message || 'Failed to start microphone');
    }
  }

  public stopListening() {
    this.stopVolumeAnalyzer();
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch (e) {
        // Ignore
      }
      this.isListening = false;
    }
  }

  public speak(text: string, onStart?: () => void, onEnd?: () => void) {
    if (!this.synthesis) {
      onEnd?.();
      return;
    }

    this.stopSpeaking();

    // Clean formatting characters like markdown bold/asterisks for natural speech
    const cleanText = text
      .replace(/\*+/g, '')
      .replace(/#+/g, '')
      .replace(/\[.*?\]\(.*?\)/g, '')
      .trim();

    if (!cleanText) {
      onEnd?.();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.lang = 'en-US';

    // Select a pleasant voice if available
    const voices = this.synthesis.getVoices();
    const preferredVoice = voices.find(v =>
      v.lang.includes('en') && (v.name.includes('Google') || v.name.includes('Natural') || v.name.includes('Samantha') || v.name.includes('Karen'))
    ) || voices.find(v => v.lang.includes('en'));

    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.onstart = () => {
      this.isSpeaking = true;
      this.activeUtterance = utterance;
      onStart?.();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      this.activeUtterance = null;
      onEnd?.();
    };

    utterance.onerror = (err) => {
      console.warn('SpeechSynthesis error:', err);
      this.isSpeaking = false;
      this.activeUtterance = null;
      onEnd?.();
    };

    this.synthesis.speak(utterance);
  }

  public stopSpeaking() {
    if (this.synthesis) {
      this.synthesis.cancel();
      this.isSpeaking = false;
      this.activeUtterance = null;
    }
  }

  public getIsListening() {
    return this.isListening;
  }

  public getIsSpeaking() {
    return this.isSpeaking;
  }
}

export const voiceService = new VoiceService();
