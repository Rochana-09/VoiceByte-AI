export interface MenuItem {
  id: string;
  name: string;
  restaurantId: string;
  restaurantName: string;
  description: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  isVeg: boolean;
  category: 'biryani' | 'pizza' | 'burger' | 'chinese' | 'dessert' | 'beverage' | 'north-indian';
  image: string;
  preparationTime: string;
  tags: string[];
  bestseller?: boolean;
  customizations?: {
    sizes?: { name: string; price: number }[];
    spiceLevels?: string[];
    addOns?: { name: string; price: number }[];
  };
}

export interface Restaurant {
  id: string;
  name: string;
  cuisine: string[];
  rating: number;
  reviews: string;
  deliveryTime: string;
  distance: string;
  priceForTwo: number;
  image: string;
  address: string;
  featuredDish: string;
  badge?: string;
}

export interface CartItem {
  id: string; // unique cart item id
  menuItem: MenuItem;
  selectedSize?: { name: string; price: number };
  selectedSpice?: string;
  selectedAddOns?: { name: string; price: number }[];
  quantity: number;
  totalPrice: number;
  instructions?: string;
}

export type OrderStatus = 'placed' | 'confirmed' | 'preparing' | 'picked_up' | 'on_the_way' | 'delivered';

export interface DeliveryPartner {
  name: string;
  phone: string;
  rating: number;
  trips: number;
  vehicle: string;
  vehicleNumber: string;
  photo: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  taxes: number;
  grandTotal: number;
  deliveryAddress: string;
  customerName: string;
  customerPhone: string;
  status: OrderStatus;
  deliveryPartner: DeliveryPartner;
  estimatedDeliveryTime: number; // in minutes
  createdAt: string;
  paymentMethod: 'UPI' | 'Card' | 'COD' | 'ApplePay';
  paymentCompleted: boolean;
}

export interface VoiceMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  suggestedActions?: string[];
  filterKeyword?: string;
  recommendedItems?: string[];
}
